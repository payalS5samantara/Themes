<div class="post post-small__single">      
   <div class="post-small__content">
      <div class="post-small__thumbnail">
         <a class="link-image-content" href="<?php the_permalink(); ?>">
            <?php if ( has_post_thumbnail()) {
               the_post_thumbnail('thumbnail');
            }?>
         </a>
      </div>
      <div class="post-small__content-inner">
         <div class="post-small__entry-meta clearfix">
            <?php consilox_posted_on(); ?>
         </div> 
         <h3 class="post-small__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3> 
      </div>    
   </div>   
</div>

  