<?php 
   $thumbnail = isset($thumbnail_size) && $thumbnail_size ? $thumbnail_size : 'post-thumbnail';
?>

<article <?php post_class('post post-three__single'); ?>>
   <?php 
         if(has_post_thumbnail()){
            echo '<div class="post-three__thumbnail">';
               echo '<a href="' . esc_url( get_permalink() ) . '">';
                  the_post_thumbnail( $thumbnail, array( 'alt' => get_the_title() ) );
               echo '</a>';
               if( get_the_date() ){
                  echo '<div class="post-three__entry-date">';
                     echo '<span class="date">' . esc_html( get_the_date('d')) . '</span>';
                     echo '<span class="month">' . esc_html( get_the_date('M')) . '</span>';
                  echo '</div>';
               } 
            echo '</div>';
         }
      ?>   
   <div class="post-three__content">
      <div class="post-three__content-inner">
         <h3 class="post-three__title">
            <a href="<?php echo esc_url( get_permalink() ) ?>"><?php the_title() ?></a>
         </h3>
         <div class="post-three__meta">
            <?php consilox_posted_on(); ?>
         </div> 
      </div>
   </div>
</article>   

  