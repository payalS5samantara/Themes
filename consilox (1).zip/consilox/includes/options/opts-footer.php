<?php
Redux::setSection( $opt_name, array(
  	'title' => esc_html__('Footer Options', 'consilox'),
  	'icon' => 'el-icon-compass',
  	'fields' => array(
	 	array(
			'id' 			=> 'copyright_default',
			'type' 		=> 'button_set',
			'title' 		=> esc_html__('Enable/Disable Copyright Text', 'consilox'),
			'options' 	=> array(
				'yes' 	=> esc_html__('Enable', 'consilox'),
				'no' 		=> esc_html__('Disable', 'consilox')
			),
			'default' 	=> 'yes'
	 	),
	 	array(
			'id' 			=> 'copyright_text',
			'type' 		=> 'editor',
			'title' 		=> esc_html__('Footer Copyright Text', 'consilox'),
			'default' 	=> esc_html__('Copyright - 2024 - Company - All rights reserved. Powered by WordPress.', 'consilox')
	 	),
  	)
));