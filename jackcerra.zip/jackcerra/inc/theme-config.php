<?php if(!function_exists('jackcerra_configs')){
    function jackcerra_configs($value){
        $configs = [
            'theme_colors' => [
                'primary'   => [
                    'title' => esc_html__('Primary', 'jackcerra'), 
                    'value' => jackcerra()->get_opt('primary_color', '#df0a0a')
                ],
                'secondary'   => [
                    'title' => esc_html__('Secondary', 'jackcerra'), 
                    'value' => jackcerra()->get_opt('secondary_color', '#1C2539')
                ],
                'third'   => [
                    'title' => esc_html__('Third', 'jackcerra'), 
                    'value' => jackcerra()->get_opt('third_color', '#518CF5')
                ],
                'body-bg'   => [
                    'title' => esc_html__('Body Background Color', 'jackcerra'), 
                    'value' => jackcerra()->get_page_opt('body_bg_color', '#fff')
                ]
            ],
            'link' => [
                'color' => jackcerra()->get_opt('link_color', ['regular' => '#df0a0a'])['regular'],
                'color-hover'   => jackcerra()->get_opt('link_color', ['hover' => '#B00F0F'])['hover'],
                'color-active'  => jackcerra()->get_opt('link_color', ['active' => '#B00F0F'])['active'],
            ],
            'gradient' => [
                'color-from' => jackcerra()->get_opt('gradient_color', ['from' => '#9E0008'])['from'],
                'color-to' => jackcerra()->get_opt('gradient_color', ['to' => '#F50000'])['to'],
            ],
               
        ];
        return $configs[$value];
    }
}
if(!function_exists('jackcerra_inline_styles')) {
    function jackcerra_inline_styles() {  
        
        $theme_colors      = jackcerra_configs('theme_colors');
        $link_color        = jackcerra_configs('link');
        $gradient_color    = jackcerra_configs('gradient');
        ob_start();
        echo ':root{';
            
            foreach ($theme_colors as $color => $value) {
                printf('--%1$s-color: %2$s;', str_replace('#', '',$color),  $value['value']);
            }
            foreach ($theme_colors as $color => $value) {
                printf('--%1$s-color-rgb: %2$s;', str_replace('#', '',$color),  jackcerra_hex_rgb($value['value']));
            }
            foreach ($link_color as $color => $value) {
                printf('--link-%1$s: %2$s;', $color, $value);
            }
            foreach ($gradient_color as $color => $value) {
                printf('--gradient-%1$s: %2$s;', $color, $value);
            }
        echo '}';

        return ob_get_clean();
         
    }
}
 