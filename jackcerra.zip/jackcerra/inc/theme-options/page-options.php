<?php
 
add_action( 'pxl_post_metabox_register', 'jackcerra_page_options_register' );
function jackcerra_page_options_register( $metabox ) {
 
	$panels = [
		'post' => [
			'opt_name'            => 'post_option',
			'display_name'        => esc_html__( 'Post Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'post_settings' => [
					'title'  => esc_html__( 'Post Options', 'jackcerra' ),
					'icon'   => 'el el-refresh',
					'fields' => array_merge(
						jackcerra_sidebar_pos_opts(['prefix' => 'post_', 'default' => true, 'default_value' => '-1']),
						array(
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Spacing Top/Bottom', 'jackcerra' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							),
					    )
					)
				]
			]
		],
		'page' => [
			'opt_name'            => 'pxl_page_options',
			'display_name'        => esc_html__( 'Page Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'Header', 'jackcerra' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
				        jackcerra_header_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						array(
							array(
				           		'id'       => 'logo_m',
					            'type'     => 'media',
					            'title'    => esc_html__('Mobile Logo', 'jackcerra'),
					            'default'  => '',
					            'url'      => false,
					        ),
					        array(
					            'id'       => 'mobile_style',
					            'type'     => 'button_set',
					            'title'    => esc_html__('Mobile Style', 'jackcerra'),
					            'options'  => array(
					                'inherit'  => esc_html__('Inherit', 'jackcerra'),
					                'light'  => esc_html__('Light', 'jackcerra'),
					                'dark'  => esc_html__('Dark', 'jackcerra'),
					            ),
					            'default'  => 'inherit',
					        ),
					        array(
				                'id'       => 'p_menu',
				                'type'     => 'select',
				                'title'    => esc_html__( 'Menu', 'jackcerra' ),
				                'options'  => jackcerra_get_nav_menu_slug(),
				                'default' => '',
				            ),
					    ),
					    array(
				            array(
				                'id'       => 'sticky_scroll',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Sticky Scroll', 'jackcerra'),
				                'options'  => array(
				                    '-1' => esc_html__('Inherit', 'jackcerra'),
				                    'pxl-sticky-stt' => esc_html__('Scroll To Top', 'jackcerra'),
				                    'pxl-sticky-stb'  => esc_html__('Scroll To Bottom', 'jackcerra'),
				                ),
				                'default'  => '-1',
				            ),
				        )
				    )
					 
				],
				'page_title' => [
					'title'  => esc_html__( 'Page Title', 'jackcerra' ),
					'icon'   => 'el el-indent-left',
					'fields' => array_merge(
				        jackcerra_page_title_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						array(
					        array(
					            'id' => 'custom_ptitle',
					            'type' => 'text',
					            'title' => esc_html__('Custom Page Title', 'jackcerra'),
					        ),
					    )
				    )
				],
				'content' => [
					'title'  => esc_html__( 'Content', 'jackcerra' ),
					'icon'   => 'el-icon-pencil',
					'fields' => array_merge(
						jackcerra_sidebar_pos_opts(['prefix' => 'page_', 'default' => false, 'default_value' => '0']),
						array(
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Spacing Top/Bottom', 'jackcerra' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							), 
					    )
					)
				],
				'footer' => [
					'title'  => esc_html__( 'Footer', 'jackcerra' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        jackcerra_footer_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						array(
							array(
				                'id'       => 'p_footer_fixed',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Footer Fixed', 'jackcerra'),
				                'options'  => array(
				                    'inherit' => esc_html__('Inherit', 'jackcerra'),
				                    'on' => esc_html__('On', 'jackcerra'),
				                    'off' => esc_html__('Off', 'jackcerra'),
				                ),
				                'default'  => 'inherit',
				            ),
						)
				    )
				],
				'colors' => [
					'title'  => esc_html__( 'Colors', 'jackcerra' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        array(
				        	array(
					            'id'          => 'body_bg_color',
					            'type'        => 'color',
					            'title'       => esc_html__('Body Background Color', 'jackcerra'),
					            'transparent' => false,
					            'default'     => ''
					        ),
				        	array(
					            'id'          => 'primary_color',
					            'type'        => 'color',
					            'title'       => esc_html__('Primary Color', 'jackcerra'),
					            'transparent' => false,
					            'default'     => ''
					        ),
					        array(
					            'id'          => 'secondary_color',
					            'type'        => 'color',
					            'title'       => esc_html__('Secondary Color', 'jackcerra'),
					            'transparent' => false,
					            'default'     => ''
					        ),
					        array(
					            'id'          => 'third_color',
					            'type'        => 'color',
					            'title'       => esc_html__('Third Color', 'jackcerra'),
					            'transparent' => false,
					            'default'     => ''
					        ),
					        array(
					            'id'          => 'gradient_color',
					            'type'        => 'color_gradient',
					            'title'       => esc_html__('Gradient Color', 'jackcerra'),
					            'transparent' => false,
					            'default'  => array(
					                'from' => '',
					                'to'   => '', 
					            ),
					        ),
					    )
				    )
				],
				'extra' => [
					'title'  => esc_html__( 'Extra', 'jackcerra' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        array(
				        	array(
					            'id' => 'body_custom_class',
					            'type' => 'text',
					            'title' => esc_html__('Body Custom Class', 'jackcerra'),
					        ),
					        array(
					            'id'       => 'site_loader',
					            'type'     => 'button_set',
					            'title'    => esc_html__('Loader', 'jackcerra'),
					            'options'  => array(
					                'inherit' => esc_html__('Inherit', 'jackcerra'),
					                'on' => esc_html__('On', 'jackcerra'),
					                'off' => esc_html__('Off', 'jackcerra'),
					            ),
					            'default'  => 'inherit',
					        ),
					        array(
					            'id'    => 'loader_style',
					            'type'  => 'select',
					            'title' => esc_html__('Loader Style', 'jackcerra'),
					            'options' => [
					                'style-default'           => esc_html__('Default', 'jackcerra'),
					                'style-digital'           => esc_html__('Digital', 'jackcerra'),
					                'style-software'           => esc_html__('Software', 'jackcerra'),
					                'style-business'           => esc_html__('Business', 'jackcerra'),
					                'style-insurance'           => esc_html__('Insurance', 'jackcerra'),
					                'style-event'           => esc_html__('Event', 'jackcerra'),
					                'style-corporate'           => esc_html__('Corporate', 'jackcerra'),
					                'style-startup'           => esc_html__('Startup', 'jackcerra'),
					                'style-app'           => esc_html__('App', 'jackcerra'),
					                'style-photography'           => esc_html__('Photography', 'jackcerra'),
					                'style-architecture'           => esc_html__('Architecture', 'jackcerra'),
					                'style-seo'           => esc_html__('Seo', 'jackcerra'),
					                'style-portfolio'           => esc_html__('Portfolio Dark', 'jackcerra'),
					                'style-portfolio2'           => esc_html__('Portfolio Light', 'jackcerra'),
					                'style-law'           => esc_html__('Law', 'jackcerra'),
					            ],
					            'default' => 'style-default',
					            'indent' => true,
					            'required' => array( 0 => 'site_loader', 1 => 'equals', 2 => 'on' ),
					        ),
					        array(
					            'id'      => 'loader_text',
					            'type'    => 'text',
					            'title'   => esc_html__('Loader Text', 'jackcerra'),
					            'default' => '',
					            'required' => array( 0 => 'loader_style', 1 => 'equals', 2 => 'style-law' ),
					        ),
					    )
				    )
				]
			]
		],
		'portfolio' => [
			'opt_name'            => 'pxl_portfolio_options',
			'display_name'        => esc_html__( 'Portfolio Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'jackcerra' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
						array(
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Content Spacing Top/Bottom', 'jackcerra' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							),
						)
				    )
				],
			]
		],
		'service' => [
			'opt_name'            => 'pxl_service_options',
			'display_name'        => esc_html__( 'Service Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'jackcerra' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
						array(
							array(
					            'id'=> 'service_external_link',
					            'type' => 'text',
					            'title' => esc_html__('External Link', 'jackcerra'),
					            'validate' => 'url',
					            'default' => '',
					        ),
							array(
					            'id'=> 'service_excerpt',
					            'type' => 'textarea',
					            'title' => esc_html__('Excerpt', 'jackcerra'),
					            'validate' => 'html_custom',
					            'default' => '',
					        ),
					        array(
					            'id'       => 'service_icon_type',
					            'type'     => 'button_set',
					            'title'    => esc_html__('Icon Type', 'jackcerra'),
					            'options'  => array(
					                'icon'  => esc_html__('Icon', 'jackcerra'),
					                'image'  => esc_html__('Image', 'jackcerra'),
					            ),
					            'default'  => 'icon'
					        ),
					        array(
					            'id'       => 'service_icon_font',
					            'type'     => 'pxl_iconpicker',
					            'title'    => esc_html__('Icon', 'jackcerra'),
					            'required' => array( 0 => 'service_icon_type', 1 => 'equals', 2 => 'icon' ),
            					'force_output' => true
					        ),
					        array(
					            'id'       => 'service_icon_img',
					            'type'     => 'media',
					            'title'    => esc_html__('Icon Image', 'jackcerra'),
					            'default' => '',
					            'required' => array( 0 => 'service_icon_type', 1 => 'equals', 2 => 'image' ),
				            	'force_output' => true
					        ),
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Content Spacing Top/Bottom', 'jackcerra' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							),
						)
				    )
				],
			]
		],
		'product' => [
			'opt_name'            => 'pxl_product_options',
			'display_name'        => esc_html__( 'Product Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'jackcerra' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
						array(
							array(
					            'id'=> 'product_label',
					            'type' => 'text',
					            'title' => esc_html__('Label', 'jackcerra'),
					            'default' => '',
					        ),
						)
				    )
				],
			]
		],
		'pxl-template' => [
			'opt_name'            => 'pxl_hidden_template_options',
			'display_name'        => esc_html__( 'Template Options', 'jackcerra' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'jackcerra' ),
					'icon'   => 'el-icon-website',
					'fields' => array(
						array(
							'id'    => 'template_type',
							'type'  => 'select',
							'title' => esc_html__('Type', 'jackcerra'),
				            'options' => [
				            	'df'       	   => esc_html__('Select Type', 'jackcerra'), 
								'header'       => esc_html__('Header', 'jackcerra'), 
								'footer'       => esc_html__('Footer', 'jackcerra'), 
								'mega-menu'    => esc_html__('Mega Menu', 'jackcerra'), 
								'page-title'   => esc_html__('Page Title', 'jackcerra'), 
								'tab' => esc_html__('Tab', 'jackcerra'),
								'hidden-panel' => esc_html__('Hidden Panel', 'jackcerra'),
								'popup' => esc_html__('Popup', 'jackcerra'),
								'slider' => esc_html__('Slider', 'jackcerra'),
				            ],
				            'default' => 'df',
				        ),
				        array(
							'id'    => 'header_type',
							'type'  => 'select',
							'title' => esc_html__('Header Type', 'jackcerra'),
				            'options' => [
				            	'px-header--default'       	   => esc_html__('Default', 'jackcerra'), 
								'px-header--transparent'       => esc_html__('Transparent', 'jackcerra'),
				            ],
				            'default' => 'px-header--default',
				            'indent' => true,
                			'required' => array( 0 => 'template_type', 1 => 'equals', 2 => 'header' ),
				        ),
					),
				    
				],
			]
		],
	];
 
	$metabox->add_meta_data( $panels );
}
 