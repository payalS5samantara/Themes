<?php

$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'jackcerra' => array(
		'title'       => 'Jackcerra',	
		'description' => '',
		'screenshot'  => $uri . 'jackcerra.png',
		'preview'     => 'https://demo.bravisthemes.com/jackcerra/',
	),
);