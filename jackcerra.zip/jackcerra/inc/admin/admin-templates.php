<?php

if( !defined( 'ABSPATH' ) )
	exit; 

class Jackcerra_Admin_Templates extends Jackcerra_Base{

	public function __construct() {
		$this->add_action( 'admin_menu', 'register_page', 20 );
	}
 
	public function register_page() {
		add_submenu_page(
			'pxlart',
		    esc_html__( 'Templates', 'jackcerra' ),
		    esc_html__( 'Templates', 'jackcerra' ),
		    'manage_options',
		    'edit.php?post_type=pxl-template',
		    false
		);
	}
}
new Jackcerra_Admin_Templates;
