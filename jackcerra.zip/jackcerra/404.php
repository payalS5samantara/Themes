<?php
/**
 * @package Bravis-Themes
 */
get_header(); ?>
<div class="container">
    <div class="row content-row">
        <div id="pxl-content-area" class="pxl-content-area col-12">
            <main id="pxl-content-main">
                <div class="pxl-error-inner">
                    <div class="pxl-error-holder">
                        <div class="pxl-error-number">404</div>
                        <h3 class="pxl-error-title">
                            <?php echo esc_html__('Page Not Found', 'jackcerra'); ?>
                        </h3>
                        <div class="pxl-error-description"><?php echo esc_html__('Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'jackcerra'); ?></div>
                        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url( '/' )); ?>">
                            <div class="searchform-wrap">
                                <input type="text" placeholder="<?php esc_attr_e('Search', 'jackcerra'); ?>" name="s" class="search-field" />
                                <button type="submit" class="search-submit"><i class="caseicon-search"></i></button>
                            </div>
                        </form>
                        <a class="btn btn-default btn-secondary" href="<?php echo esc_url(home_url('/')); ?>">
                            <span class="pxl--btn-text"><?php echo esc_html__('Go Back Home', 'jackcerra'); ?></span>
                            <span class="pxl--text-wrap">
                                <span class="pxl--btn-text1"><?php echo esc_html__('Go Back Home', 'jackcerra'); ?></span>
                                <span class="pxl--btn-text2"><?php echo esc_html__('Go Back Home', 'jackcerra'); ?></span>
                            </span>
                        </a>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
<?php get_footer();
