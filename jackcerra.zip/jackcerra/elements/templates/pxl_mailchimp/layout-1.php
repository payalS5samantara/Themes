<?php if(class_exists('MC4WP_Container')) : ?>
	<div class="pxl-mailchimp pxl-mailchimp-l1 <?php echo esc_attr($settings['btn_width'].' '.$settings['button_style'].' '.$settings['style'].' '.$settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
		<?php if($settings['style'] == 'style-box-info') : ?>
			<?php if(!empty($settings['title']) || !empty($settings['sub_title'])) : ?>
				<div class="pxl-mailchimp--meta">
					<h4 class="wg-title"><?php echo esc_attr($settings['title']); ?></h4>
					<div class="wg-subtitle"><?php echo esc_attr($settings['sub_title']); ?></div>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<?php echo do_shortcode('[mc4wp_form]'); ?>
	</div>
<?php endif; ?>
