<div class="pxl-process pxl-process3 <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--inner">
        <?php if(!empty($settings['image']['id'])) : 
            $img = pxl_get_image_by_size( array(
                'attach_id'  => $settings['image']['id'],
                'thumb_size' => 'full',
            ));
            $thumbnail = $img['thumbnail'];
            ?>
            <div class="pxl-item--image">
                
                <?php echo pxl_print_html($thumbnail); ?>

                <?php if(!empty($settings['step'])) : ?>
                    <div class="pxl-item--step <?php echo esc_attr($settings['step_position']); ?>">
                        <span><?php echo esc_attr($settings['step']); ?></span>
                    </div>
                <?php endif; ?>
            
            </div>
        <?php endif; ?>
        <div class="pxl-item--meta">
	        <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title el-empty"><?php echo pxl_print_html($settings['title']); ?></<?php echo esc_attr($settings['title_tag']); ?>>
	        <div class="pxl-item--description el-empty"><?php echo pxl_print_html($settings['desc']); ?></div>
		</div>    
    </div>
</div>