<div class="pxl-social-share">
    <label class="el-empty pxl-mr-20"><?php echo esc_attr($settings['label']); ?></label>
    <div class="pxl-social--list">
        <a class="fb-social" title="<?php echo esc_attr__('Facebook', 'jackcerra'); ?>" target="_blank" href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="caseicon-facebook"></i></a>
        <a class="tw-social" title="<?php echo esc_attr__('Twitter', 'jackcerra'); ?>" target="_blank" href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>%20"><i class="caseicon-twitter"></i></a>
        <a class="pin-social" title="<?php echo esc_attr__('Pinterest', 'jackcerra'); ?>" target="_blank" href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php echo esc_url($img_url[0]); ?>&description=<?php the_title(); ?>%20"><i class="caseicon-pinterest"></i></a>
        <a class="lin-social" title="<?php echo esc_attr__('LinkedIn', 'jackcerra'); ?>" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>%20"><i class="caseicon-linkedin"></i></a>
    </div>
</div>