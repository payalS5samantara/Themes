<div class="pxl-banner pxl-banner2">
	<div class="pxl-banner-inner">
		
		<?php if(!empty($settings['banner_image']['id'])) : 
			$image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full'; 
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => $image_size,
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--image">
				<div class="pxl-item--imgprimary <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
					<?php echo pxl_print_html($thumbnail); ?>
				</div>
			</div>
		<?php endif; ?>

		<?php if(!empty($settings['banner_title'])) : ?>
			<div class="pxl-item--meta">
				<?php if(!empty($settings['banner_number'])) : ?>
					<span class="pxl--counter-number">
						<span class="pxl--counter-value" data-duration="2000" data-to-value="<?php echo esc_attr($settings['banner_number']); ?>" data-delimiter="">1</span>
					</span>
				<?php endif; ?>
				<h5 class="pxl-item--title"><?php echo pxl_print_html($settings['banner_title']); ?></h5>
			</div>
		<?php endif; ?>

	</div>
</div>