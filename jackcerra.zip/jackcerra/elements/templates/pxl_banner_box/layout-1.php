<div class="pxl-banner pxl-banner1">
	<div class="pxl-banner-inner">
		
		<?php if(!empty($settings['banner_image']['id'])) : 
			$image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full'; 
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => $image_size,
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--image">
				<div class="pxl-item--imgprimary <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
					<?php echo pxl_print_html($thumbnail); ?>
				</div>
				
				<?php if(!empty($settings['banner_image2']['id'])) : 
					$img_2 = pxl_get_image_by_size( array(
						'attach_id'  => $settings['banner_image2']['id'],
						'thumb_size' => 'full',
					));
					$thumbnail_2 = $img_2['thumbnail']; ?>
					<div class="pxl-item--imgsecondary <?php echo esc_attr($settings['pxl_animate_img2']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img2']); ?>ms"><?php echo pxl_print_html($thumbnail_2); ?></div>
				<?php endif; ?>

				<?php if(!empty($settings['shape_image']['id'])) : 
					$img_shape = pxl_get_image_by_size( array(
						'attach_id'  => $settings['shape_image']['id'],
						'thumb_size' => 'full',
					));
					$thumbnail_shape = $img_shape['thumbnail']; ?>
					<div class="pxl-item--shapewp <?php echo esc_attr($settings['pxl_animate_shape']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_shape']); ?>ms">
						<div class="pxl-item--shape <?php echo esc_attr($settings['shape_effect']); ?>"><?php echo pxl_print_html($thumbnail_shape); ?></div>
					</div>
				<?php endif; ?>
			
			</div>
		<?php endif; ?>

		<?php if(!empty($settings['banner_title'])) : ?>
			<div class="pxl-item--meta">
				<?php if(!empty($settings['banner_number'])) : ?>
					<span class="pxl--counter-number">
						<span class="pxl--counter-value" data-duration="2000" data-to-value="<?php echo esc_attr($settings['banner_number']); ?>" data-delimiter="">1</span>
					</span>
				<?php endif; ?>
				<div class="pxl-item--title"><?php echo esc_attr($settings['banner_title']); ?></div>
				<svg width="37" height="17" viewBox="0 0 37 17" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M37 0V17L0 0H37Z" fill="#000"/>
				</svg>
			</div>
		<?php endif; ?>

	</div>
</div>