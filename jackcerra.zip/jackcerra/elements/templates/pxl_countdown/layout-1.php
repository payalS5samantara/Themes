<?php
$default_settings = [
    'date' => '2030/10/10',
];
$settings = array_merge($default_settings, $settings);
extract($settings); 
$month = esc_html__('Month', 'jackcerra');
$months = esc_html__('Months', 'jackcerra');
$day = esc_html__('Day', 'jackcerra');
$days = esc_html__('Days', 'jackcerra');
$hour = esc_html__('Hour', 'jackcerra');
$hours = esc_html__('Hours', 'jackcerra');
$minute = esc_html__('Mins', 'jackcerra');
$minutes = esc_html__('Mins', 'jackcerra');
$second = esc_html__('Sec', 'jackcerra');
$seconds = esc_html__('Sec', 'jackcerra');
?>
<div class="pxl-countdown-wrap">
	<div class="pxl-countdown pxl-countdown-layout1 <?php echo esc_attr($settings['pxl_animate']); ?>" 
		data-month="<?php echo esc_attr($month) ?>"
		data-months="<?php echo esc_attr($months) ?>"
		data-day="<?php echo esc_attr($day) ?>"
		data-days="<?php echo esc_attr($days) ?>"
		data-hour="<?php echo esc_attr($hour) ?>"
		data-hours="<?php echo esc_attr($hours) ?>"
		data-minute="<?php echo esc_attr($minute) ?>"
		data-minutes="<?php echo esc_attr($minutes) ?>"
		data-second="<?php echo esc_attr($second) ?>"
		data-seconds="<?php echo esc_attr($seconds) ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
		<div class="pxl-countdown-inner" data-count-down="<?php echo esc_attr($date);?>"></div>
	</div>
</div>