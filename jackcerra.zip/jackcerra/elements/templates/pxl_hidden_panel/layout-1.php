<?php 
$template = (int)$widget->get_setting('content_template','0');
if($template > 0 ){
	if ( !has_action( 'pxl_anchor_target_hidden_panel_'.$template) ){
		add_action( 'pxl_anchor_target_hidden_panel_'.$template, 'jackcerra_hook_anchor_hidden_panel' );
	} 
}
?>
<div class="pxl-hidden-panel-button pxl-anchor-button pxl-cursor--cta <?php echo esc_attr($settings['btn_style']); ?>">
	<?php if($settings['btn_style'] == 'style-1') : ?>
		<span class="pxl-icon-round">
			<span class="pxl-icon-round1"></span>
			<span class="pxl-icon-round2"></span>
			<span class="pxl-icon-round3"></span>
			<span class="pxl-icon-round4"></span>
			<span class="pxl-icon-round5"></span>
			<span class="pxl-icon-round6"></span>
			<span class="pxl-icon-round7"></span>
			<span class="pxl-icon-round8"></span>
			<span class="pxl-icon-round9"></span>
		</span>
	<?php endif; ?>
	<?php if($settings['btn_style'] == 'style-2' || $settings['btn_style'] == 'style-3') : ?>
		<span class="pxl-icon-square">
			<span class="pxl-icon-square1"></span>
			<span class="pxl-icon-square2"></span>
			<span class="pxl-icon-square3"></span>
		</span>
	<?php endif; ?>
</div>