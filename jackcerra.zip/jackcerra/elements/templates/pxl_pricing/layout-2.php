<?php
if ( ! empty( $settings['button_link']['url'] ) ) {
    $widget->add_render_attribute( 'button', 'href', $settings['button_link']['url'] );

    if ( $settings['button_link']['is_external'] ) {
        $widget->add_render_attribute( 'button', 'target', '_blank' );
    }

    if ( $settings['button_link']['nofollow'] ) {
        $widget->add_render_attribute( 'button', 'rel', 'nofollow' );
    }
}
?>
<div class="pxl-pricing pxl-pricing2 <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--price">
        <span class="pxl-item--currency"><?php echo pxl_print_html($settings['currency']); ?></span>
        <span class="pxl-price--number"><?php echo pxl_print_html($settings['price']); ?></span>
        <div class="pxl-item--number"><?php echo pxl_print_html($settings['price']); ?></div>
    </div>
    <div class="pxl-item--subtitle el-empty"><?php echo esc_attr($settings['subtitle']); ?></div>
    <h5 class="pxl-item--title el-empty"><?php echo esc_attr($settings['title']); ?></h5>
    <?php if(isset($settings['feature']) && !empty($settings['feature']) && count($settings['feature'])): ?>
        <div class="pxl-item--feature">
            <?php foreach ($settings['feature'] as $key => $value): ?>
                <div class="<?php echo esc_attr($value['active']); ?>">
                    <i class="caseicon-check pxl-mr-7"></i>
                    <?php if($value['active'] == 'non-active') { ?><del><?php } ?>
                        <?php echo pxl_print_html($value['feature_text'])?>
                    <?php if($value['active'] == 'non-active') { ?></del><?php } ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if(!empty($settings['button_text'])) : ?>
        <div class="pxl-item--button">
            <a class="btn" <?php pxl_print_html($widget->get_render_attribute_string( 'button' )); ?>>
                <?php echo esc_attr($settings['button_text']); ?>
            </a>
        </div>
    <?php endif; ?>
</div>