<div class="pxl-image-box pxl-image-box1 <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
	<div class="pxl-banner-inner">
		<?php if(!empty($settings['banner_image']['id'])) :
			$image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full';
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => $image_size,
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--image">
				<?php echo pxl_print_html($thumbnail); ?>
			</div>
		<?php endif; ?>
		<div class="pxl-item--holder">
			<?php if ( !empty($settings['pxl_icon']['value']) ) : ?>
	            <div class="pxl-item--icon">
	                <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
	            </div>
	        <?php endif; ?>
	        <?php if(!empty($settings['banner_title'])) : ?>
				<h5 class="pxl-item--title">
					<?php echo esc_attr($settings['banner_title']); ?>
				</h5>
			<?php endif; ?>
			<?php if(!empty($settings['banner_content'])) : ?>
				<div class="pxl-item--content">
					<?php echo pxl_print_html($settings['banner_content']); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>