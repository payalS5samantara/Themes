<div class="pxl-navigation-carousel">
    <div class="pxl-navigation-arrow pxl-navigation-arrow-prev <?php echo esc_attr($settings['style']); ?>"><i class="flaticon-left-arrow rtl-icon"></i></div>
    <div class="pxl-navigation-arrow pxl-navigation-arrow-next <?php echo esc_attr($settings['style']); ?>"><i class="flaticon-right-arrow rtl-icon"></i></div>
</div>