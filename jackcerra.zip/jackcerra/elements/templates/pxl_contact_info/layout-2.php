<div class="pxl-contact-info pxl-contact-info2 <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--inner pxl-item--flexnw">
        <?php if(!empty($settings['avatar']['id'])) :
            $img = pxl_get_image_by_size( array(
                'attach_id'  => $settings['avatar']['id'],
                'thumb_size' => '300x300',
            ));
            $thumbnail = $img['thumbnail'];
            ?>
            <div class="pxl-item--image pxl-mr-16">
                <?php echo pxl_print_html($thumbnail); ?>
            </div>
        <?php endif; ?>
        <div class="pxl-item--meta">
            <h5 class="pxl-item--title el-empty"><?php echo pxl_print_html($settings['title']); ?></h5>
            <div class="pxl-item--subtitle el-empty"><?php echo pxl_print_html($settings['sub_title']); ?></div>
        </div>
    </div>
</div>