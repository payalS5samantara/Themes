<?php
/**
 * Template part for displaying posts in loop
 *
 * @package Bravis-Themes
 */
$post_tag = jackcerra()->get_theme_opt( 'post_tag', true );
$post_navigation = jackcerra()->get_theme_opt( 'post_navigation', false );
$post_author_info = jackcerra()->get_theme_opt( 'post_author_info', false );
$post_social_share = jackcerra()->get_theme_opt( 'post_social_share', false );
$tags_list = get_the_tag_list();
$post_date = jackcerra()->get_theme_opt( 'post_date', true );
?>
<article id="pxl-post-<?php the_ID(); ?>" <?php post_class('pxl---post'); ?>>
    <?php if (has_post_thumbnail()) {
        echo '<div class="pxl-item--image">'; ?>
            <?php the_post_thumbnail('jackcerra-large'); ?>
            <?php if($post_date) : ?>
                <span class="pxl-item--date pxl-r-20"><?php echo get_the_date(); ?></span>
            <?php endif; ?>
        <?php echo '</div>';
    }?>
    <div class="pxl-item--holder">
        <?php jackcerra()->blog->get_post_metas(); ?>
        <div class="pxl-item--content clearfix">
            <?php
                the_content();
                wp_link_pages( array(
                    'before'      => '<div class="page-links">',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ) );
            ?>
        </div>

    </div>

    <?php if($post_tag && $tags_list || $post_social_share ) :  ?>
        <div class="pxl--post-footer">
            <?php if($post_tag) { jackcerra()->blog->get_tagged_in(); } ?>
            <?php if($post_social_share) { jackcerra()->blog->get_socials_share(); } ?>
        </div>
    <?php endif; ?>

    <?php if($post_author_info) { jackcerra()->blog->get_post_author_info(); } ?>

    <?php if($post_navigation) { jackcerra()->blog->get_post_nav(); } ?>
</article><!-- #post -->