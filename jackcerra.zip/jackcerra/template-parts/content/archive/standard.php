<?php
/**
 * @package Bravis-Themes
 */
$archive_readmore_text = jackcerra()->get_theme_opt('archive_readmore_text', esc_html__('Read Article', 'jackcerra'));
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('pxl---post pxl-item--archive pxl-item--standard'); ?>>
    <?php if (has_post_thumbnail()) { 
        echo '<div class="pxl-item--image">'; ?>
            <a href="<?php echo esc_url( get_permalink()); ?>"><?php the_post_thumbnail('jackcerra-large'); ?></a>
        <?php echo '</div>';
    } ?>
    <?php jackcerra()->blog->get_archive_meta(); ?>
    <div class="pxl-item--holder">
        <h2 class="pxl-item--title">
            <a href="<?php echo esc_url( get_permalink()); ?>" title="<?php the_title_attribute(); ?>">
                <?php if(is_sticky()) { ?>
                    <i class="caseicon-check-mark pxl-mr-4"></i>
                <?php } ?>
                <?php the_title(); ?>
            </a>
        </h2>
        <div class="pxl-item--excerpt">
            <?php
                jackcerra()->blog->get_excerpt();
                wp_link_pages( array(
                    'before'      => '<div class="page-links">',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ) );
            ?>
        </div>
        <div class="pxl-item--readmore">
            <a class="btn--readmore" href="<?php echo esc_url( get_permalink()); ?>">
                <span class="btn-readmore--icon pxl-mr-10"><i class="flaticon-right rtl-reverse"></i></span>
                <span class="btn-readmore--text"><?php echo jackcerra_html($archive_readmore_text); ?></span>
            </a>
        </div>
    </div>
</article>