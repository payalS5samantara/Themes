<?php
/**
 * @package Bravis-Themes
 */

dynamic_sidebar( jackcerra()->get_sidebar() );