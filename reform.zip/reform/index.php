<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: //codex.wordpress.org/Template_Hierarchy
 *
 * @package REFORM
 * @since REFORM 1.0
 */

$reform_template = apply_filters( 'reform_filter_get_template_part', reform_blog_archive_get_template() );

if ( ! empty( $reform_template ) && 'index' != $reform_template ) {

	get_template_part( $reform_template );

} else {

	reform_storage_set( 'blog_archive', true );

	get_header();

	if ( have_posts() ) {

		// Query params
		$reform_stickies   = is_home()
								|| ( in_array( reform_get_theme_option( 'post_type' ), array( '', 'post' ) )
									&& (int) reform_get_theme_option( 'parent_cat' ) == 0
									)
										? get_option( 'sticky_posts' )
										: false;
		$reform_post_type  = reform_get_theme_option( 'post_type' );
		$reform_args       = array(
								'blog_style'     => reform_get_theme_option( 'blog_style' ),
								'post_type'      => $reform_post_type,
								'taxonomy'       => reform_get_post_type_taxonomy( $reform_post_type ),
								'parent_cat'     => reform_get_theme_option( 'parent_cat' ),
								'posts_per_page' => reform_get_theme_option( 'posts_per_page' ),
								'sticky'         => reform_get_theme_option( 'sticky_style', 'inherit' ) == 'columns'
															&& is_array( $reform_stickies )
															&& count( $reform_stickies ) > 0
															&& get_query_var( 'paged' ) < 1
								);

		reform_blog_archive_start();

		do_action( 'reform_action_blog_archive_start' );

		if ( is_author() ) {
			do_action( 'reform_action_before_page_author' );
			get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/author-page' ) );
			do_action( 'reform_action_after_page_author' );
		}

		if ( reform_get_theme_option( 'show_filters', 0 ) ) {
			do_action( 'reform_action_before_page_filters' );
			reform_show_filters( $reform_args );
			do_action( 'reform_action_after_page_filters' );
		} else {
			do_action( 'reform_action_before_page_posts' );
			reform_show_posts( array_merge( $reform_args, array( 'cat' => $reform_args['parent_cat'] ) ) );
			do_action( 'reform_action_after_page_posts' );
		}

		do_action( 'reform_action_blog_archive_end' );

		reform_blog_archive_end();

	} else {

		if ( is_search() ) {
			get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/content', 'none-search' ), 'none-search' );
		} else {
			get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/content', 'none-archive' ), 'none-archive' );
		}
	}

	get_footer();
}
