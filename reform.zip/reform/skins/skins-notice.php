<?php
/**
 * The template to display Admin notices
 *
 * @package REFORM
 * @since REFORM 1.0.64
 */

$reform_skins_url  = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$reform_skins_args = get_query_var( 'reform_skins_notice_args' );
?>
<div class="reform_admin_notice reform_skins_notice notice notice-info is-dismissible" data-notice="skins">
	<?php
	// Theme image
	$reform_theme_img = reform_get_file_url( 'screenshot.jpg' );
	if ( '' != $reform_theme_img ) {
		?>
		<div class="reform_notice_image"><img src="<?php echo esc_url( $reform_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'reform' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="reform_notice_title">
		<?php esc_html_e( 'New skins are available', 'reform' ); ?>
	</h3>
	<?php

	// Description
	$reform_total      = $reform_skins_args['update'];	// Store value to the separate variable to avoid warnings from ThemeCheck plugin!
	$reform_skins_msg  = $reform_total > 0
							// Translators: Add new skins number
							? '<strong>' . sprintf( _n( '%d new version', '%d new versions', $reform_total, 'reform' ), $reform_total ) . '</strong>'
							: '';
	$reform_total      = $reform_skins_args['free'];
	$reform_skins_msg .= $reform_total > 0
							? ( ! empty( $reform_skins_msg ) ? ' ' . esc_html__( 'and', 'reform' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d free skin', '%d free skins', $reform_total, 'reform' ), $reform_total ) . '</strong>'
							: '';
	$reform_total      = $reform_skins_args['pay'];
	$reform_skins_msg .= $reform_skins_args['pay'] > 0
							? ( ! empty( $reform_skins_msg ) ? ' ' . esc_html__( 'and', 'reform' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d paid skin', '%d paid skins', $reform_total, 'reform' ), $reform_total ) . '</strong>'
							: '';
	?>
	<div class="reform_notice_text">
		<p>
			<?php
			// Translators: Add new skins info
			echo wp_kses_data( sprintf( __( "We are pleased to announce that %s are available for your theme", 'reform' ), $reform_skins_msg ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="reform_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $reform_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'reform' );
			?>
		</a>
	</div>
</div>
