<?php
/**
 * Required plugins
 *
 * @package REFORM
 * @since REFORM 1.76.0
 */

// THEME-SUPPORTED PLUGINS
// If plugin not need - remove its settings from next array
//----------------------------------------------------------
if ( ! function_exists( 'reform_skin_required_plugins' ) ) {
	add_action( 'after_setup_theme', 'reform_skin_required_plugins', -1 );
	function reform_skin_required_plugins() {
		$reform_theme_required_plugins_groups = array(
			'core'          => esc_html__( 'Core', 'reform' ),
			'page_builders' => esc_html__( 'Page Builders', 'reform' ),
			'ecommerce'     => esc_html__( 'E-Commerce & Donations', 'reform' ),
			'socials'       => esc_html__( 'Socials and Communities', 'reform' ),
			'events'        => esc_html__( 'Events and Appointments', 'reform' ),
			'content'       => esc_html__( 'Content', 'reform' ),
			'other'         => esc_html__( 'Other', 'reform' ),
		);
		$reform_theme_required_plugins        = array(
			// Core
			'trx_addons'                 => array(
				'title'       => esc_html__( 'ThemeREX Addons', 'reform' ),
				'description' => esc_html__( "Will allow you to install recommended plugins, demo content, and improve the theme's functionality overall with multiple theme options", 'reform' ),
				'required'    => true, // Check this plugin in the list on load Theme Dashboard
				'logo'        => 'trx_addons.png',
				'group'       => $reform_theme_required_plugins_groups['core'],
			),
			// Page Builders
			'elementor'                  => array(
				'title'       => esc_html__( 'Elementor', 'reform' ),
				'description' => esc_html__( "Is a beautiful PageBuilder, even the free version of which allows you to create great pages using a variety of modules.", 'reform' ),
				'required'    => false, // Leave this plugin unchecked on load Theme Dashboard
				'logo'        => 'elementor.png',
				'group'       => $reform_theme_required_plugins_groups['page_builders'],
			),
			'gutenberg'                  => array(
				'title'       => esc_html__( 'Gutenberg', 'reform' ),
				'description' => esc_html__( "It's a posts editor coming in place of the classic TinyMCE. Can be installed and used in parallel with Elementor", 'reform' ),
				'required'    => false,
				'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
				'logo'        => 'gutenberg.png',
				'group'       => $reform_theme_required_plugins_groups['page_builders'],
			),
			// Events
			'the-events-calendar'        => array(
				'title'       => esc_html__( 'The Events Calendar', 'reform' ),
				'description' => '',
				'required'    => false,
				'logo'        => 'the-events-calendar.png',
				'group'       => $reform_theme_required_plugins_groups['events'],
			),
			'event-tickets'              => array(
				'title'       => esc_html__( 'Event Tickets', 'reform' ),
				'description' => '',
				'required'    => false,
				'logo'        => 'event-tickets.png',
				'group'       => $reform_theme_required_plugins_groups['events'],
			),
			// E-Commerce & Donations
			'give'                       => array(
				'title'       => esc_html__( 'Give', 'reform' ),
				'description' => '',
				'required'    => false,
				'logo'        => 'give.png',
				'group'       => $reform_theme_required_plugins_groups['ecommerce'],
			),
			// Content
			'sitepress-multilingual-cms' => array(
				'title'       => esc_html__( 'WPML - Sitepress Multilingual CMS', 'reform' ),
				'description' => esc_html__( "Allows you to make your website multilingual", 'reform' ),
				'required'    => false,
				'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
				'logo'        => 'sitepress-multilingual-cms.png',
				'group'       => $reform_theme_required_plugins_groups['content'],
			),
			'metform'                    => array(
				'title'       => esc_html__( 'MetForm', 'reform' ),
				'description' => esc_html__( "Contact Form, Survey, Quiz, & Custom Form Builder for Elementor", 'reform' ),
				'required'    => false,
				'logo'        => 'metform.png',
				'group'       => $reform_theme_required_plugins_groups['content'],
			),
			// Other
			'trx_updater'                => array(
				'title'       => esc_html__( 'ThemeREX Updater', 'reform' ),
				'description' => esc_html__( "Update theme and theme-specific plugins from developer's upgrade server.", 'reform' ),
				'required'    => false,
				'logo'        => 'trx_updater.png',
				'group'       => $reform_theme_required_plugins_groups['other'],
			)
		);

		if ( REFORM_THEME_FREE ) {
			unset( $reform_theme_required_plugins['sitepress-multilingual-cms'] );
			unset( $reform_theme_required_plugins['trx_updater'] );
		}

		// Add plugins list to the global storage
		reform_storage_set( 'required_plugins', $reform_theme_required_plugins );
	}
}
