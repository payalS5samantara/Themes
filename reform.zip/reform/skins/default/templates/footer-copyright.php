<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package REFORM
 * @since REFORM 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
				<?php
					$reform_copyright = reform_get_theme_option( 'copyright' );
					if ( ! empty( $reform_copyright ) ) {
						// Replace {{Y}} or {Y} with the current year
						$reform_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $reform_copyright );
						// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
						$reform_copyright = reform_prepare_macros( $reform_copyright );
						// Display copyright
						echo wp_kses( nl2br( $reform_copyright ), 'reform_kses_content' );
					}
				?>
			</div>
		</div>
	</div>
</div>