<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package REFORM
 * @since REFORM 1.0.10
 */

// Footer sidebar
$reform_footer_name    = reform_get_theme_option( 'footer_widgets' );
$reform_footer_present = ! reform_is_off( $reform_footer_name ) && is_active_sidebar( $reform_footer_name );
if ( $reform_footer_present ) {
	reform_storage_set( 'current_sidebar', 'footer' );
	ob_start();
	if ( is_active_sidebar( $reform_footer_name ) ) {
		dynamic_sidebar( $reform_footer_name );
	}
	$reform_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $reform_out ) ) {
		$reform_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $reform_out );
		$reform_need_columns = true;   //or check: strpos($reform_out, 'columns_wrap')===false;
		if ( $reform_need_columns ) {
			$reform_columns = max( 0, (int) reform_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $reform_columns ) {
				$reform_columns = min( 4, max( 1, reform_tags_count( $reform_out, 'aside' ) ) );
			}
			if ( $reform_columns > 1 ) {
				$reform_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $reform_columns ) . ' widget', $reform_out );
			} else {
				$reform_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area sc_layouts_row">
			<?php do_action( 'reform_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<div class="content_wrap">
					<?php
					if ( $reform_need_columns ) {
						?>
						<div class="columns_wrap">
						<?php
					}
					do_action( 'reform_action_before_sidebar', 'footer' );
					reform_show_layout( $reform_out );
					do_action( 'reform_action_after_sidebar', 'footer' );
					if ( $reform_need_columns ) {
						?>
						</div>
						<?php
					}
					?>
				</div>
			</div>
			<?php do_action( 'reform_action_after_sidebar_wrap', 'footer' ); ?>
		</div>
		<?php
	}
}
