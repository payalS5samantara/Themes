<?php
/**
 * The template to display default site header
 *
 * @package REFORM
 * @since REFORM 1.0
 */

$reform_header_css   = '';
$reform_header_image = get_header_image();
$reform_header_video = reform_get_header_video();
if ( ! empty( $reform_header_image ) && reform_trx_addons_featured_image_override( reform_is_singular() || reform_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$reform_header_image = reform_get_current_mode_image( $reform_header_image );
}
?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $reform_header_image ) || ! empty( $reform_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $reform_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $reform_header_image ) {
		echo ' ' . esc_attr( reform_add_inline_css_class( 'background-image: url(' . esc_url( $reform_header_image ) . ');' ) );
	}
	if ( reform_is_singular() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $reform_header_video ) ) {
		get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/header-navi' ) );

	// Page title and breadcrumbs area
	if ( ! reform_is_single() ) {
		get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/header-title' ) );
	}
	?>
</header>
