<?php
/**
 * The template to display Admin notices
 *
 * @package REFORM
 * @since REFORM 1.0.1
 */

$reform_theme_slug = get_template();
$reform_theme_obj  = wp_get_theme( $reform_theme_slug );
?>
<div class="reform_admin_notice reform_welcome_notice notice notice-info is-dismissible" data-notice="admin">
	<?php
	// Theme image
	$reform_theme_img = reform_get_file_url( 'screenshot.jpg' );
	if ( '' != $reform_theme_img ) {
		?>
		<div class="reform_notice_image"><img src="<?php echo esc_url( $reform_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'reform' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="reform_notice_title">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name and version to the 'Welcome' message
				__( 'Welcome to %1$s v.%2$s', 'reform' ),
				$reform_theme_obj->get( 'Name' ) . ( REFORM_THEME_FREE ? ' ' . __( 'Free', 'reform' ) : '' ),
				$reform_theme_obj->get( 'Version' )
			)
		);
		?>
	</h3>
	<?php

	// Description
	?>
	<div class="reform_notice_text">
		<p class="reform_notice_text_description">
			<?php
			echo str_replace( '. ', '.<br>', wp_kses_data( $reform_theme_obj->description ) );
			?>
		</p>
		<p class="reform_notice_text_info">
			<?php
			echo wp_kses_data( __( 'Attention! Plugin "ThemeREX Addons" is required! Please, install and activate it!', 'reform' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="reform_notice_buttons">
		<?php
		// Link to the page 'About Theme'
		?>
		<a href="<?php echo esc_url( admin_url() . 'themes.php?page=reform_about' ); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> 
			<?php
			echo esc_html__( 'Install plugin "ThemeREX Addons"', 'reform' );
			?>
		</a>
	</div>
</div>
