<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package REFORM
 * @since REFORM 1.0
 */

$reform_template_args = get_query_var( 'reform_template_args' );

if ( is_array( $reform_template_args ) ) {
	$reform_columns       = empty( $reform_template_args['columns'] ) ? 1 : max( 1, $reform_template_args['columns'] );
	$reform_blog_style    = array( $reform_template_args['type'], $reform_columns );
	$reform_columns_class = reform_get_column_class( 1, $reform_columns, ! empty( $reform_template_args['columns_tablet']) ? $reform_template_args['columns_tablet'] : '', ! empty($reform_template_args['columns_mobile']) ? $reform_template_args['columns_mobile'] : '' );
} else {
	$reform_template_args = array();
	$reform_blog_style    = explode( '_', reform_get_theme_option( 'blog_style' ) );
	$reform_columns       = empty( $reform_blog_style[1] ) ? 1 : max( 1, $reform_blog_style[1] );
	$reform_columns_class = reform_get_column_class( 1, $reform_columns );
}
$reform_expanded   = ! reform_sidebar_present() && reform_get_theme_option( 'expand_content' ) == 'expand';

$reform_post_format = get_post_format();
$reform_post_format = empty( $reform_post_format ) ? 'standard' : str_replace( 'post-format-', '', $reform_post_format );

?><div class="<?php
	if ( ! empty( $reform_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( reform_is_blog_style_use_masonry( $reform_blog_style[0] )
			? 'masonry_item masonry_item-1_' . esc_attr( $reform_columns )
			: esc_attr( $reform_columns_class )
			);
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $reform_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $reform_columns )
				. ' post_layout_' . esc_attr( $reform_blog_style[0] )
				. ' post_layout_' . esc_attr( $reform_blog_style[0] ) . '_' . esc_attr( $reform_columns )
	);
	reform_add_blog_animation( $reform_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	$reform_hover      = ! empty( $reform_template_args['hover'] ) && ! reform_is_inherit( $reform_template_args['hover'] )
							? $reform_template_args['hover']
							: reform_get_theme_option( 'image_hover' );

	$reform_components = ! empty( $reform_template_args['meta_parts'] )
							? ( is_array( $reform_template_args['meta_parts'] )
								? $reform_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $reform_template_args['meta_parts'] ) )
								)
							: reform_array_get_keys_by_value( reform_get_theme_option( 'meta_parts' ) );

	reform_show_post_featured( apply_filters( 'reform_filter_args_featured',
		array(
			'thumb_size' => ! empty( $reform_template_args['thumb_size'] )
								? $reform_template_args['thumb_size']
								: reform_get_thumb_size(
									strpos( reform_get_theme_option( 'body_style' ), 'full' ) !== false
										? ( $reform_columns > 2 ? 'big' : 'full' )
										: ( $reform_columns > 2
											? 'med'
											: ( $reform_expanded || $reform_columns == 1 ? 
												( $reform_expanded && $reform_columns == 1 ? 'huge' : 'big' ) 
												: 'med' 
												)
											)												
								),
			'hover'      => $reform_hover,
			'meta_parts' => $reform_components,
			'no_links'   => ! empty( $reform_template_args['no_links'] ),
		),
		'content-classic',
		$reform_template_args
	) );

	// Title and post meta
	$reform_show_title = get_the_title() != '';
	$reform_show_meta  = count( $reform_components ) > 0;

	if ( $reform_show_title ) {
		?><div class="post_header entry-header"><?php
			// Categories
			if ( apply_filters( 'reform_filter_show_blog_categories', $reform_show_meta && in_array( 'categories', $reform_components ), array( 'categories' ), 'classic' ) ) {
				do_action( 'reform_action_before_post_category' );
				?><div class="post_category"><?php
					reform_show_post_meta( apply_filters(
														'reform_filter_post_meta_args',
														array(
															'components' => 'categories',
															'seo'        => false,
															'echo'       => true,
															),
														'hover_' . $reform_hover, 1
														)
										);
				?></div><?php
				$reform_components = reform_array_delete_by_value( $reform_components, 'categories' );
				do_action( 'reform_action_after_post_category' );
			}
			// Post title
			if ( apply_filters( 'reform_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'reform_action_before_post_title' );
				if ( empty( $reform_template_args['no_links'] ) ) {
					the_title( sprintf( '<h3 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				} else {
					the_title( '<h3 class="post_title entry-title">', '</h3>' );
				}
				do_action( 'reform_action_after_post_title' );
			}
		?></div><?php
	}
	
	// Post meta
	if ( apply_filters( 'reform_filter_show_blog_meta', $reform_show_meta, $reform_components, 'classic' ) ) {
		if ( count( $reform_components ) > 0 ) {
			do_action( 'reform_action_before_post_meta' );
			reform_show_post_meta(
				apply_filters(
					'reform_filter_post_meta_args', array(
						'components' => join( ',', $reform_components ),
						'seo'        => false,
						'echo'       => true,
						'author_avatar' => false,
					), $reform_blog_style[0], $reform_columns
				)
			);
			do_action( 'reform_action_after_post_meta' );
		}
	}

	// Post content
	ob_start();
	if ( apply_filters( 'reform_filter_show_blog_excerpt', ( ! isset( $reform_template_args['hide_excerpt'] ) || (int)$reform_template_args['hide_excerpt'] == 0 ) && (int)reform_get_theme_option( 'excerpt_length' ) > 0, 'classic' ) ) {
		reform_show_post_content( $reform_template_args, '<div class="post_content_inner">', '</div>' );
	}
	$reform_content = ob_get_contents();
	ob_end_clean();

	reform_show_layout( $reform_content, '<div class="post_content entry-content">', '</div>' );

		
	// More button
	if ( apply_filters( 'reform_filter_show_blog_readmore', ! $reform_show_title || ! empty( $reform_template_args['more_button'] ), 'classic' ) ) {
		if ( empty( $reform_template_args['no_links'] ) ) {
			do_action( 'reform_action_before_post_readmore' );
			reform_show_post_more_link( $reform_template_args, '<p>', '</p>' );
			do_action( 'reform_action_after_post_readmore' );
		}
	}

	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
