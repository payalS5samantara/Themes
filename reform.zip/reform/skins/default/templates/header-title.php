<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package REFORM
 * @since REFORM 1.0
 */

// Page (category, tag, archive, author) title

if ( reform_need_page_title() ) {
	reform_sc_layouts_showed( 'title', true );
	?>
	<div class="top_panel_title sc_layouts_row">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Blog/Page title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$reform_blog_title           = reform_get_blog_title();
							$reform_blog_title_text      = '';
							$reform_blog_title_class     = '';
							$reform_blog_title_link      = '';
							$reform_blog_title_link_text = '';
							if ( is_array( $reform_blog_title ) ) {
								$reform_blog_title_text      = $reform_blog_title['text'];
								$reform_blog_title_class     = ! empty( $reform_blog_title['class'] ) ? ' ' . $reform_blog_title['class'] : '';
								$reform_blog_title_link      = ! empty( $reform_blog_title['link'] ) ? $reform_blog_title['link'] : '';
								$reform_blog_title_link_text = ! empty( $reform_blog_title['link_text'] ) ? $reform_blog_title['link_text'] : '';
							} else {
								$reform_blog_title_text = $reform_blog_title;
							}
							?>
							<h1 class="sc_layouts_title_caption<?php echo esc_attr( $reform_blog_title_class ); ?>"<?php
								if ( reform_is_on( reform_get_theme_option( 'seo_snippets' ) ) ) {
									?> itemprop="headline"<?php
								}
							?>>
								<?php
								$reform_top_icon = reform_get_term_image_small();
								if ( ! empty( $reform_top_icon ) ) {
									$reform_attr = reform_getimagesize( $reform_top_icon );
									?>
									<img src="<?php echo esc_url( $reform_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'reform' ); ?>"
										<?php
										if ( ! empty( $reform_attr[3] ) ) {
											reform_show_layout( $reform_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $reform_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $reform_blog_title_link ) && ! empty( $reform_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $reform_blog_title_link ); ?>" class="theme_button sc_layouts_title_link"><?php echo esc_html( $reform_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'reform_action_breadcrumbs' );
						$reform_breadcrumbs = ob_get_contents();
						ob_end_clean();
						reform_show_layout( $reform_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
