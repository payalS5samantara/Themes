<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package REFORM
 * @since REFORM 1.0
 */

$reform_args = get_query_var( 'reform_logo_args' );

// Site logo
$reform_logo_type   = isset( $reform_args['type'] ) ? $reform_args['type'] : '';
$reform_logo_image  = reform_get_logo_image( $reform_logo_type );
$reform_logo_text   = reform_is_on( reform_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$reform_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $reform_logo_image['logo'] ) || ! empty( $reform_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $reform_logo_image['logo'] ) ) {
			if ( empty( $reform_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric( $reform_logo_image['logo'] ) && (int) $reform_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$reform_attr = reform_getimagesize( $reform_logo_image['logo'] );
				echo '<img src="' . esc_url( $reform_logo_image['logo'] ) . '"'
						. ( ! empty( $reform_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $reform_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $reform_logo_text ) . '"'
						. ( ! empty( $reform_attr[3] ) ? ' ' . wp_kses_data( $reform_attr[3] ) : '' )
						. '>';
			}
		} else {
			reform_show_layout( reform_prepare_macros( $reform_logo_text ), '<span class="logo_text">', '</span>' );
			reform_show_layout( reform_prepare_macros( $reform_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
