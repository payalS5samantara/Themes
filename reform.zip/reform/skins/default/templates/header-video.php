<?php
/**
 * The template to display the background video in the header
 *
 * @package REFORM
 * @since REFORM 1.0.14
 */
$reform_header_video = reform_get_header_video();
$reform_embed_video  = '';
if ( ! empty( $reform_header_video ) && ! reform_is_from_uploads( $reform_header_video ) ) {
	if ( reform_is_youtube_url( $reform_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $reform_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php reform_show_layout( reform_get_embed_video( $reform_header_video ) ); ?></div>
		<?php
	}
}