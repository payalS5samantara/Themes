<?php
/**
 * The template to display the user's avatar, bio and socials on the Author page
 *
 * @package REFORM
 * @since REFORM 1.71.0
 */
?>

<div class="author_page author vcard"<?php
	if ( reform_is_on( reform_get_theme_option( 'seo_snippets' ) ) ) {
		?> itemprop="author" itemscope="itemscope" itemtype="<?php echo esc_attr( reform_get_protocol( true ) ); ?>//schema.org/Person"<?php
	}
?>>

	<div class="author_avatar"<?php
		if ( reform_is_on( reform_get_theme_option( 'seo_snippets' ) ) ) {
			?> itemprop="image"<?php
		}
	?>>
		<?php
		$reform_mult = reform_get_retina_multiplier();
		echo get_avatar( get_the_author_meta( 'user_email' ), 120 * $reform_mult );
		?>
	</div>

	<h4 class="author_title"<?php
		if ( reform_is_on( reform_get_theme_option( 'seo_snippets' ) ) ) {
			?> itemprop="name"<?php
		}
	?>><span class="fn"><?php the_author(); ?></span></h4>

	<?php
	$reform_author_description = get_the_author_meta( 'description' );
	if ( ! empty( $reform_author_description ) ) {
		?>
		<div class="author_bio"<?php
			if ( reform_is_on( reform_get_theme_option( 'seo_snippets' ) ) ) {
				?> itemprop="description"<?php
			}
		?>><?php echo wp_kses( wpautop( $reform_author_description ), 'reform_kses_content' ); ?></div>
		<?php
	}
	?>

	<div class="author_details">
		<span class="author_posts_total">
			<?php
			$reform_posts_total = count_user_posts( get_the_author_meta('ID'), 'post' );	// get_the_author_posts() return posts number by post_type from first post in the result
			if ( $reform_posts_total > 0 ) {
				// Translators: Add the author's posts number to the message
				echo wp_kses( sprintf( _n( '%s article published', '%s articles published', $reform_posts_total, 'reform' ),
										'<span class="author_posts_total_value">' . number_format_i18n( $reform_posts_total ) . '</span>'
								 		),
							'reform_kses_content'
							);
			} else {
				esc_html_e( 'No posts published.', 'reform' );
			}
			?>
		</span><?php
			ob_start();
			do_action( 'reform_action_user_meta', 'author-page' );
			$reform_socials = ob_get_contents();
			ob_end_clean();
			reform_show_layout( $reform_socials,
				'<span class="author_socials"><span class="author_socials_caption">' . esc_html__( 'Follow:', 'reform' ) . '</span>',
				'</span>'
			);
		?>
	</div>

</div>
