<article <?php post_class( 'post_item_single post_item_404' ); ?>>
	<div class="post_content">
		<h1 class="page_title"><?php esc_html_e( '404', 'reform' ); ?></h1>
		<div class="page_info">
			<h3 class="page_subtitle"><?php esc_html_e( 'Oops...', 'reform' ); ?></h3>
			<p class="page_description"><?php echo wp_kses( __( "We're sorry, but something went wrong.", 'reform' ), 'reform_kses_content' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="go_home theme_button"><?php esc_html_e( 'Homepage', 'reform' ); ?></a>
		</div>
	</div>
</article>
