<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package REFORM
 * @since REFORM 1.0.06
 */

$reform_header_css   = '';
$reform_header_image = get_header_image();
if ( ! empty( $reform_header_image ) && reform_trx_addons_featured_image_override( reform_is_singular() || reform_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$reform_header_image = reform_get_current_mode_image( $reform_header_image );
}

$reform_header_id = reform_get_custom_header_id();
$reform_header_meta = reform_get_custom_layout_meta( $reform_header_id );
if ( ! empty( $reform_header_meta['margin'] ) ) {
	reform_add_inline_css( sprintf( '.page_content_wrap{padding-top:%s}', esc_attr( reform_prepare_css_value( $reform_header_meta['margin'] ) ) ) );
	reform_storage_set( 'custom_header_margin', reform_prepare_css_value( $reform_header_meta['margin'] ) );
}

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr( $reform_header_id ); ?> top_panel_custom_<?php echo esc_attr( sanitize_title( get_the_title( $reform_header_id ) ) ); ?>
				<?php
				echo ! empty( $reform_header_image )
					? ' with_bg_image'
					: ' without_bg_image';
				if ( '' != $reform_header_image ) {
					echo ' ' . esc_attr( reform_add_inline_css_class( 'background-image: url(' . esc_url( $reform_header_image ) . ');' ) );
				}
				if ( reform_is_single() && has_post_thumbnail() ) {
					echo ' with_featured_image';
				}
				?>
">
	<?php

	// Custom header's layout
	do_action( 'reform_action_show_layout', $reform_header_id );

	?>
</header>
