<?php
/**
 * The default template to displaying related posts
 *
 * @package REFORM
 * @since REFORM 1.0.54
 */

$reform_link        = get_permalink();
$reform_post_format = get_post_format();
$reform_post_format = empty( $reform_post_format ) ? 'standard' : str_replace( 'post-format-', '', $reform_post_format );
?><div id="post-<?php the_ID(); ?>" <?php post_class( 'related_item post_format_' . esc_attr( $reform_post_format ) ); ?> data-post-id="<?php the_ID(); ?>">
	<?php
	reform_show_post_featured(
		array(
			'thumb_size' => apply_filters( 'reform_filter_related_thumb_size', reform_get_thumb_size(
				(int) reform_get_theme_option( 'related_posts' ) == 1 || (int) reform_get_theme_option( 'related_columns' ) == 1 ? 'full' : 'big' )
			),
		)
	);
	?>
	<div class="post_header entry-header">
		<h6 class="post_title entry-title"><a href="<?php echo esc_url( $reform_link ); ?>"><?php
			if ( '' == get_the_title() ) {
				esc_html_e( 'No title', 'reform' );
			} else {
				the_title();
			}
		?></a></h6>
		<?php
		if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
			?>
			<span class="post_date"><a href="<?php echo esc_url( $reform_link ); ?>"><?php echo wp_kses_data( reform_get_date() ); ?></a></span>
			<?php
		}
		?>
	</div>
</div>
