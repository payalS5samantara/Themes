<?php
// Add theme-specific CSS-animations
if ( ! function_exists( 'reform_elm_add_theme_animations' ) ) {
	add_filter( 'elementor/controls/animations/additional_animations', 'reform_elm_add_theme_animations' );
	function reform_elm_add_theme_animations( $animations ) {
		/* To add a theme-specific animations to the list:
			1) Merge to the array 'animations': array(
													esc_html__( 'Theme Specific', 'reform' ) => array(
														'ta_custom_1' => esc_html__( 'Custom 1', 'reform' )
													)
												)
			2) Add a CSS rules for the class '.ta_custom_1' to create a custom entrance animation
		*/
		$animations = array_merge(
						$animations,
						array(
							esc_html__( 'Theme Specific', 'reform' ) => array(
																			'ta_fadeinup' 		=> esc_html__( 'Fade In Up (Short)', 'reform' ),
																			'ta_fadeinright'	=> esc_html__( 'Fade In Right (Short)', 'reform' ),
																			'ta_fadeinleft'		=> esc_html__( 'Fade In Left (Short)', 'reform' ),
																			'ta_fadeindown'		=> esc_html__( 'Fade In Down (Short)', 'reform' ),
																			'ta_fadein' 		=> esc_html__( 'Fade In (Short)', 'reform' ),
																			'ta_popup' 			=> esc_html__( 'Pop Up', 'reform' ),
																			'ta_infiniterotate' => esc_html__( 'Infinite Rotate', 'reform' ),
																			)
							)
						);
		return $animations;
	}
}
