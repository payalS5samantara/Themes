<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package REFORM
 * @since REFORM 1.0
 */

							do_action( 'reform_action_page_content_end_text' );
							
							// Widgets area below the content
							reform_create_widgets_area( 'widgets_below_content' );
						
							do_action( 'reform_action_page_content_end' );
							?>
						</div>
						<?php
						
						do_action( 'reform_action_after_page_content' );

						// Show main sidebar
						get_sidebar();

						do_action( 'reform_action_content_wrap_end' );
						?>
					</div>
					<?php

					do_action( 'reform_action_after_content_wrap' );

					// Widgets area below the page and related posts below the page
					$reform_body_style = reform_get_theme_option( 'body_style' );
					$reform_widgets_name = reform_get_theme_option( 'widgets_below_page', 'hide' );
					$reform_show_widgets = ! reform_is_off( $reform_widgets_name ) && is_active_sidebar( $reform_widgets_name );
					$reform_show_related = reform_is_single() && reform_get_theme_option( 'related_position', 'below_content' ) == 'below_page';
					if ( $reform_show_widgets || $reform_show_related ) {
						if ( 'fullscreen' != $reform_body_style ) {
							?>
							<div class="content_wrap">
							<?php
						}
						// Show related posts before footer
						if ( $reform_show_related ) {
							do_action( 'reform_action_related_posts' );
						}

						// Widgets area below page content
						if ( $reform_show_widgets ) {
							reform_create_widgets_area( 'widgets_below_page' );
						}
						if ( 'fullscreen' != $reform_body_style ) {
							?>
							</div>
							<?php
						}
					}
					do_action( 'reform_action_page_content_wrap_end' );
					?>
			</div>
			<?php
			do_action( 'reform_action_after_page_content_wrap' );

			// Don't display the footer elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ( ! reform_is_singular( 'post' ) && ! reform_is_singular( 'attachment' ) ) || ! in_array ( reform_get_value_gp( 'action' ), array( 'full_post_loading', 'prev_post_loading' ) ) ) {
				
				// Skip link anchor to fast access to the footer from keyboard
				?>
				<a id="footer_skip_link_anchor" class="reform_skip_link_anchor" href="#"></a>
				<?php

				do_action( 'reform_action_before_footer' );

				// Footer
				$reform_footer_type = reform_get_theme_option( 'footer_type' );
				if ( 'custom' == $reform_footer_type && ! reform_is_layouts_available() ) {
					$reform_footer_type = 'default';
				}
				get_template_part( apply_filters( 'reform_filter_get_template_part', "templates/footer-" . sanitize_file_name( $reform_footer_type ) ) );

				do_action( 'reform_action_after_footer' );

			}
			?>

			<?php do_action( 'reform_action_page_wrap_end' ); ?>

		</div>

		<?php do_action( 'reform_action_after_page_wrap' ); ?>

	</div>

	<?php do_action( 'reform_action_after_body' ); ?>

	<?php wp_footer(); ?>

</body>
</html>