<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package REFORM
 * @since REFORM 1.0
 */

if ( reform_sidebar_present() ) {
	
	$reform_sidebar_type = reform_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $reform_sidebar_type && ! reform_is_layouts_available() ) {
		$reform_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $reform_sidebar_type ) {
		// Default sidebar with widgets
		$reform_sidebar_name = reform_get_theme_option( 'sidebar_widgets' );
		reform_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $reform_sidebar_name ) ) {
			dynamic_sidebar( $reform_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$reform_sidebar_id = reform_get_custom_sidebar_id();
		do_action( 'reform_action_show_layout', $reform_sidebar_id );
	}
	$reform_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $reform_out ) ) {
		$reform_sidebar_position    = reform_get_theme_option( 'sidebar_position' );
		$reform_sidebar_position_ss = reform_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $reform_sidebar_position );
			echo ' sidebar_' . esc_attr( $reform_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $reform_sidebar_type );

			$reform_sidebar_scheme = apply_filters( 'reform_filter_sidebar_scheme', reform_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $reform_sidebar_scheme ) && ! reform_is_inherit( $reform_sidebar_scheme ) && 'custom' != $reform_sidebar_type ) {
				echo ' scheme_' . esc_attr( $reform_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="reform_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'reform_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $reform_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$reform_title = apply_filters( 'reform_filter_sidebar_control_title', 'float' == $reform_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'reform' ) : '' );
				$reform_text  = apply_filters( 'reform_filter_sidebar_control_text', 'above' == $reform_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'reform' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $reform_title ); ?>"><?php echo esc_html( $reform_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'reform_action_before_sidebar', 'sidebar' );
				reform_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $reform_out ) );
				do_action( 'reform_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'reform_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
