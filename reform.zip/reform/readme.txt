== Reform ==
Version: 1.0.0
Copyright: 2025, AxiomThemes
WordPress version: required at least 5.5, tested up to 6.8
License: GNU General Public License v2.0 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


I. Installation

1. In your admin panel, go to 'Appearance > Themes' and click the 'Add New' button.
2. Click 'Upload' and 'Choose File', then select the theme's .zip file. Click 'Install Now'.
3. Click 'Activate' to use your new theme right away.


II. Theme Features Usage

All available options can be used from 'Appearance->Customize' or from 'Theme Panel->Theme Options'.

For the full realization of their capabilities, the theme requires a satellite plugin 'ThemeREX Addons'.
Its installation is offered immediately after theme activation. You can also install it later
from the menu 'Appearance->Install plugins'.
Please install and activate it before starting to use the theme Reform.

Also the theme supports many popular plugins such as 'Elementor' and many more.
They can be installed after theme activation from the menu 'Theme Panel->Theme Dashboard->Plugins'.


III. Documentation

Theme documentation is available on https://doc.themerex.net/reform/


IV. Resources

1) Google fonts
   Licensed under one of the following: (SIL Open Font License, 1.1), (Apache License, version 2.0), or (Ubuntu Font License, 1.0)

2) Icons (css/font-icons/*.*)
   The icon set used in Reform is Fontello.
   Copyright: Roman Shmelev (shmelev), Vitaly Puzrin (puzrin), Aleksey Zapparov (ixti), Evgeny Shkuropat (shkuropat), Vladimir Zapparov (dervus)
   Resource URI: http://fontello.com
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: https://github.com/fontello/fontello/blob/master/LICENSE

3) js/bideo.js
   Copyright: Rishabh (https://github.com/rishabhp)
   Resource URI: https://github.com/rishabhp/bideo.js?utm_source=hashnode.com
   License: MIT license (http://opensource.org/licenses/MIT)

4) js/colorpicker/spectrum/spectrum.js
   Copyright: Brian Grinstead (https://github.com/bgrins)
   Resource URI: https://github.com/bgrins/spectrum
   License: MIT license (http://opensource.org/licenses/MIT)

5) js/jquery.tubular.js
   Copyright: Sean McCambridge
   Resource URI: http://www.seanmccambridge.com/tubular
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: https://code.google.com/archive/p/jquery-tubular/

6) js/superfish/superfish.js
   Copyright: Joel Birch
   Resource URI: https://github.com/joeldbirch/superfish/
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: js/superfish/MIT-LICENSE.txt

7) Images come from:
   https://depositphotos.com/
   https://peopleimages.com/
   https://unsplash.com/
   https://flickr.com/
   https://www.shutterstock.com/
   https://www.pexels.com/
   https://www.freepik.com/
   https://www.midjourney.com/
   https://elements.envato.com/
   https://www.lummi.ai/
   
	https://www.freepik.com/premium-photo/african-representative-giving-interview_28033870.htm#fromView=image_search&page=1&position=7&uuid=b5e524e5-2f28-4d0b-931e-9e0c70591575
	https://www.freepik.com/free-photo/business-executives-applauding-business-meeting_8236875.htm#fromView=image_search&page=1&position=2&uuid=5e18198c-8287-46ec-9b50-4596a25fc831
	https://www.freepik.com/free-photo/businessman-reading-newspaper_2862204.htm#fromView=image_search&page=1&position=0&uuid=18aaa9ff-d8f3-4411-aa80-3b94be99eb5c
	https://www.freepik.com/premium-photo/close-up-little-child-kid-boy-hands-grabbing-putting-stack-coins-glass-jar-with-save_16951620.htm#fromView=image_search&page=1&position=18&uuid=a3d97f4a-7f25-481a-a350-bbf2eb0b6976
	https://www.freepik.com/free-photo/smiley-senior-woman-posing-inside-medium-shot_33299286.htm#fromView=image_search&page=1&position=1&uuid=84228d40-d02d-4a84-9457-22bfdc61a812
	https://www.freepik.com/premium-photo/group-people-applauding-speech-their-colleague-while-sitting-table-conference_28033580.htm#fromView=image_search&page=1&position=25&uuid=668debe2-030c-4c61-94cd-aad2cca2060e
	https://www.freepik.com/premium-photo/medical-team-having-meeting-with-doctors-white-lab-coats-surgical-scrubs-seated-table-discussing-patients-working-online-using-computers-medical-industryxa_361524620.htm#fromView=image_search&page=1&position=15&uuid=06f3982b-af1a-4155-868b-2711202b6ce4
	https://www.freepik.com/premium-photo/person-holding-coin-jar-with-plant_5481248.htm#fromView=image_search&page=1&position=41&uuid=a1fac06b-98da-4471-bdf5-4d5fd07a5a77
	https://www.freepik.com/free-photo/skilled-intelligence-agent-secure-landline-phone-call_416754345.htm#fromView=image_search&page=1&position=0&uuid=66b91e9f-75e8-4ba0-8280-661dcf1f44a0
	https://www.freepik.com/free-photo/smiling-senior-businesswoman-sitting-meeting_1022727.htm#fromView=image_search&page=1&position=0&uuid=a1c0f099-8c08-45fa-81f1-5b3f38b30c82
	https://www.freepik.com/free-photo/usa-independence-day-concept-with-declaration_2278273.htm#fromView=image_search&page=1&position=0&uuid=72ee129d-fe29-4a96-9049-fb21bc748d46

	https://unsplash.com/photos/photo-of-capital-hill-washington-dc-oN_cUY1v7hs
	https://unsplash.com/photos/person-holding-tool-during-daytime-8KfCR12oeUM
	https://unsplash.com/photos/blue-and-white-train-on-rail-road-during-daytime-NnRv949hZ1Q
	https://unsplash.com/photos/beige-concrete-building-near-cars-HhmCIJTLuGY
	https://unsplash.com/photos/people-in-conference-nwLTVwb7DbU
	https://unsplash.com/photos/people-sitting-on-stage-ZG1WIcFHAkQ
	https://unsplash.com/photos/a-podium-with-flags-in-a-room-I306rDlvTYY
	https://unsplash.com/photos/a-podium-with-flags-in-a-room-I306rDlvTYY
	https://unsplash.com/photos/woman-holding-does-anything-even-matter-anymore-signage-near-building-at-daytime-kvHk3mccNj0
	https://unsplash.com/photos/george-w-bush-standing-on-lectern-during-daytime-DhwKbmdlJa0
	https://unsplash.com/photos/barack-obama-v_e3Hha4EBA
	https://unsplash.com/photos/group-of-people-standing-surrounded-on-burning-tipi-tent-during-daytime-2yddyPBemIk
	https://unsplash.com/photos/statue-of-liberty-printed-on-blue-and-white-wall-zLsBlEKIu1k
	https://unsplash.com/photos/person-holding-white-and-red-box--LCjFBEgioM
	https://unsplash.com/photos/timelapse-photo-of-highway-during-golden-hour-45FJgZMXCK8
	https://unsplash.com/photos/low-angle-photo-of-us-flag-placed-on-gray-pole-S9J1HqoL9ns
	https://unsplash.com/photos/low-angle-photo-of-us-flag-placed-on-gray-pole-S9J1HqoL9ns
	https://unsplash.com/photos/a-very-tall-building-with-a-lot-of-lights-on-it-hWMp_XLCB8k
	https://unsplash.com/photos/president-barack-obama-WYmjDP_8kMU
	https://unsplash.com/photos/building-with-refugees-welcome-signage-uHDbnG-Avpc
	https://unsplash.com/photos/white-printed-paper-spFYbCSF-Ec
	https://unsplash.com/photos/group-of-people-standing-near-trees-jXPQY1em3Ew
	https://unsplash.com/photos/a-blue-van-parked-on-top-of-a-grass-covered-field-JAGvVkCs27s
	https://unsplash.com/photos/us-a-flag-on-pole-mFFDfg60IJw
	https://unsplash.com/photos/hands-formed-together-with-red-heart-paint-cAtzHUz7Z8g
	https://unsplash.com/photos/buildings-with-ornate-arches-and-detailed-facades-DH_jZuC0PfY
	https://unsplash.com/photos/man-standing-on-lectern-surrounded-by-people-cR03g2ud84g
	https://unsplash.com/photos/girl-holding-us-flag-on-grassland-rklMnaXqEPI
	https://unsplash.com/photos/100-us-dollar-banknote-rKPiuXLq29A

	https://www.shutterstock.com/ru/image-photo/female-hands-handcuffs-hold-dollars-isolated-1864375669
	https://www.shutterstock.com/ru/image-photo/organization-female-representative-speaking-press-conference-1974026084
	https://www.shutterstock.com/ru/image-photo/politics-giving-interview-journalists-2402264741
	https://www.shutterstock.com/ru/image-photo/fire-fighters-putting-out-house-697223872
	https://www.shutterstock.com/ru/image-photo/side-view-social-media-agents-taking-1141272149
	https://www.shutterstock.com/ru/image-photo/aerial-view-curve-road-car-trough-1374224765
	https://www.shutterstock.com/ru/image-photo/man-putting-his-vote-do-ballot-1490322299
	https://www.shutterstock.com/ru/image-photo/hand-children-holding-young-plant-sunlight-1654357528
	https://www.shutterstock.com/image-photo/group-people-working-charitable-foundation-happy-1692488662
	https://www.shutterstock.com/image-photo/patriotic-elections-america-2020-african-american-1694278885
	https://www.shutterstock.com/image-photo/car-crash-traffic-accident-injured-young-1721672770
	https://www.shutterstock.com/image-photo/close-man-holding-pink-piggybank-while-1734236675
	https://www.shutterstock.com/image-photo/portrait-confident-woman-march-fighting-freedom-1761099722
	https://www.shutterstock.com/image-photo/focused-builder-wearing-hardhat-holding-long-1829387204
	https://www.shutterstock.com/image-photo/waist-portrait-africanamerican-man-giving-interview-1873904056
	https://www.shutterstock.com/image-photo/waist-portrait-smiling-africanamerican-man-giving-1873904200
	https://www.shutterstock.com/image-photo/american-flag-waving-us-capitol-hill-1915477927
	https://www.shutterstock.com/image-photo/mature-social-worker-talking-senior-man-1973009405
	https://www.shutterstock.com/image-photo/portrait-young-organization-representative-speaking-press-1974026093
	https://www.shutterstock.com/image-photo/close-organization-representative-speaking-press-conference-1974026339
	https://www.shutterstock.com/image-photo/happy-smiling-middle-aged-woman-orange-2041397759
	https://www.shutterstock.com/image-photo/desert-comes-alive-palm-springs-green-2068175144
	https://www.shutterstock.com/image-photo/diverse-african-men-sitting-city-while-2145645233
	https://www.shutterstock.com/ru/image-photo/young-nurse-communicating-senior-man-who-2189378941
	https://www.shutterstock.com/ru/image-photo/owner-feeding-her-pet-home-2282192053
	https://www.shutterstock.com/image-photo/smiling-woman-curly-hair-coat-rides-2288114477
	https://www.shutterstock.com/image-photo/foggy-morning-dubai-downtown-uae-2289728105
	https://www.shutterstock.com/image-photo/portrait-senior-man-beard-businessman-suit-2304494381
	https://www.shutterstock.com/image-photo/members-diverse-charity-group-provide-assistance-2357647833
	https://www.shutterstock.com/image-photo/highlevel-political-forum-two-caucasian-male-2379829035
	https://www.shutterstock.com/image-photo/wonderful-sincere-cheerful-couple-gray-haired-2381393109
	https://www.shutterstock.com/image-photo/politics-giving-his-speech-conference-2402264709
	https://www.shutterstock.com/image-photo/young-biracial-woman-poses-proudly-her-2423291399
	https://www.shutterstock.com/image-photo/couple-runners-sportswear-numbers-resting-after-2427392897
	https://www.shutterstock.com/image-photo/happy-senior-man-voting-elections-united-2433504087
	https://www.shutterstock.com/image-photo/serious-united-states-presidential-candidate-answers-2448358661
	https://www.shutterstock.com/image-photo/mature-smiling-woman-keeping-hand-on-2453038501
	https://www.shutterstock.com/image-photo/pretty-blonde-woman-walking-sunny-city-2487355307
	https://www.shutterstock.com/image-photo/studio-portrait-cheerful-adult-daughter-hugging-2589707713

	https://www.pexels.com/ru-ru/photo/4427507/
	https://www.pexels.com/ru-ru/photo/4427624/
	https://www.pexels.com/ru-ru/photo/7103179/
	https://www.pexels.com/photo/professional-woman-sitting-beside-a-wooden-table-6170896/
	https://www.pexels.com/photo/freedom-black-police-history-6257069/
	https://www.pexels.com/photo/people-street-freedom-black-6257216/
	https://www.pexels.com/photo/man-in-blue-suit-sitting-on-brown-wooden-armchair-and-looking-at-the-camera-7841416/
	https://www.pexels.com/photo/a-man-in-suit-while-reading-a-document-7841425/
	https://www.pexels.com/photo/man-in-blue-suit-jacket-holding-brown-rifle-7841504/
	https://www.pexels.com/photo/volunteers-standing-on-green-grass-field-while-smiling-at-the-camera-5029855/https://www.pexels.com/photo/volunteers-standing-on-green-grass-field-while-smiling-at-the-camera-5029855/

   License: watermark distribution only

Other custom js files and images are our own creation and is licensed under the same license as this theme.