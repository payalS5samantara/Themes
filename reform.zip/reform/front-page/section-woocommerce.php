<?php
$reform_woocommerce_sc = reform_get_theme_option( 'front_page_woocommerce_products' );
if ( ! empty( $reform_woocommerce_sc ) ) {
	?><div class="front_page_section front_page_section_woocommerce<?php
		$reform_scheme = reform_get_theme_option( 'front_page_woocommerce_scheme' );
		if ( ! empty( $reform_scheme ) && ! reform_is_inherit( $reform_scheme ) ) {
			echo ' scheme_' . esc_attr( $reform_scheme );
		}
		echo ' front_page_section_paddings_' . esc_attr( reform_get_theme_option( 'front_page_woocommerce_paddings' ) );
		if ( reform_get_theme_option( 'front_page_woocommerce_stack' ) ) {
			echo ' sc_stack_section_on';
		}
	?>"
			<?php
			$reform_css      = '';
			$reform_bg_image = reform_get_theme_option( 'front_page_woocommerce_bg_image' );
			if ( ! empty( $reform_bg_image ) ) {
				$reform_css .= 'background-image: url(' . esc_url( reform_get_attachment_url( $reform_bg_image ) ) . ');';
			}
			if ( ! empty( $reform_css ) ) {
				echo ' style="' . esc_attr( $reform_css ) . '"';
			}
			?>
	>
	<?php
		// Add anchor
		$reform_anchor_icon = reform_get_theme_option( 'front_page_woocommerce_anchor_icon' );
		$reform_anchor_text = reform_get_theme_option( 'front_page_woocommerce_anchor_text' );
		if ( ( ! empty( $reform_anchor_icon ) || ! empty( $reform_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
			echo do_shortcode(
				'[trx_sc_anchor id="front_page_section_woocommerce"'
											. ( ! empty( $reform_anchor_icon ) ? ' icon="' . esc_attr( $reform_anchor_icon ) . '"' : '' )
											. ( ! empty( $reform_anchor_text ) ? ' title="' . esc_attr( $reform_anchor_text ) . '"' : '' )
											. ']'
			);
		}
	?>
		<div class="front_page_section_inner front_page_section_woocommerce_inner
			<?php
			if ( reform_get_theme_option( 'front_page_woocommerce_fullheight' ) ) {
				echo ' reform-full-height sc_layouts_flex sc_layouts_columns_middle';
			}
			?>
				"
				<?php
				$reform_css      = '';
				$reform_bg_mask  = reform_get_theme_option( 'front_page_woocommerce_bg_mask' );
				$reform_bg_color_type = reform_get_theme_option( 'front_page_woocommerce_bg_color_type' );
				if ( 'custom' == $reform_bg_color_type ) {
					$reform_bg_color = reform_get_theme_option( 'front_page_woocommerce_bg_color' );
				} elseif ( 'scheme_bg_color' == $reform_bg_color_type ) {
					$reform_bg_color = reform_get_scheme_color( 'bg_color', $reform_scheme );
				} else {
					$reform_bg_color = '';
				}
				if ( ! empty( $reform_bg_color ) && $reform_bg_mask > 0 ) {
					$reform_css .= 'background-color: ' . esc_attr(
						1 == $reform_bg_mask ? $reform_bg_color : reform_hex2rgba( $reform_bg_color, $reform_bg_mask )
					) . ';';
				}
				if ( ! empty( $reform_css ) ) {
					echo ' style="' . esc_attr( $reform_css ) . '"';
				}
				?>
		>
			<div class="front_page_section_content_wrap front_page_section_woocommerce_content_wrap content_wrap woocommerce">
				<?php
				// Content wrap with title and description
				$reform_caption     = reform_get_theme_option( 'front_page_woocommerce_caption' );
				$reform_description = reform_get_theme_option( 'front_page_woocommerce_description' );
				if ( ! empty( $reform_caption ) || ! empty( $reform_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					// Caption
					if ( ! empty( $reform_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<h2 class="front_page_section_caption front_page_section_woocommerce_caption front_page_block_<?php echo ! empty( $reform_caption ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( $reform_caption, 'reform_kses_content' );
						?>
						</h2>
						<?php
					}

					// Description (text)
					if ( ! empty( $reform_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<div class="front_page_section_description front_page_section_woocommerce_description front_page_block_<?php echo ! empty( $reform_description ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( wpautop( $reform_description ), 'reform_kses_content' );
						?>
						</div>
						<?php
					}
				}

				// Content (widgets)
				?>
				<div class="front_page_section_output front_page_section_woocommerce_output list_products shop_mode_thumbs">
					<?php
					if ( 'products' == $reform_woocommerce_sc ) {
						$reform_woocommerce_sc_ids      = reform_get_theme_option( 'front_page_woocommerce_products_per_page' );
						$reform_woocommerce_sc_per_page = count( explode( ',', $reform_woocommerce_sc_ids ) );
					} else {
						$reform_woocommerce_sc_per_page = max( 1, (int) reform_get_theme_option( 'front_page_woocommerce_products_per_page' ) );
					}
					$reform_woocommerce_sc_columns = max( 1, min( $reform_woocommerce_sc_per_page, (int) reform_get_theme_option( 'front_page_woocommerce_products_columns' ) ) );
					echo do_shortcode(
						"[{$reform_woocommerce_sc}"
										. ( 'products' == $reform_woocommerce_sc
												? ' ids="' . esc_attr( $reform_woocommerce_sc_ids ) . '"'
												: '' )
										. ( 'product_category' == $reform_woocommerce_sc
												? ' category="' . esc_attr( reform_get_theme_option( 'front_page_woocommerce_products_categories' ) ) . '"'
												: '' )
										. ( 'best_selling_products' != $reform_woocommerce_sc
												? ' orderby="' . esc_attr( reform_get_theme_option( 'front_page_woocommerce_products_orderby' ) ) . '"'
													. ' order="' . esc_attr( reform_get_theme_option( 'front_page_woocommerce_products_order' ) ) . '"'
												: '' )
										. ' per_page="' . esc_attr( $reform_woocommerce_sc_per_page ) . '"'
										. ' columns="' . esc_attr( $reform_woocommerce_sc_columns ) . '"'
						. ']'
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
