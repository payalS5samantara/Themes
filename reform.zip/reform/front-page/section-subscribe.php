<div class="front_page_section front_page_section_subscribe<?php
	$reform_scheme = reform_get_theme_option( 'front_page_subscribe_scheme' );
	if ( ! empty( $reform_scheme ) && ! reform_is_inherit( $reform_scheme ) ) {
		echo ' scheme_' . esc_attr( $reform_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( reform_get_theme_option( 'front_page_subscribe_paddings' ) );
	if ( reform_get_theme_option( 'front_page_subscribe_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$reform_css      = '';
		$reform_bg_image = reform_get_theme_option( 'front_page_subscribe_bg_image' );
		if ( ! empty( $reform_bg_image ) ) {
			$reform_css .= 'background-image: url(' . esc_url( reform_get_attachment_url( $reform_bg_image ) ) . ');';
		}
		if ( ! empty( $reform_css ) ) {
			echo ' style="' . esc_attr( $reform_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$reform_anchor_icon = reform_get_theme_option( 'front_page_subscribe_anchor_icon' );
	$reform_anchor_text = reform_get_theme_option( 'front_page_subscribe_anchor_text' );
if ( ( ! empty( $reform_anchor_icon ) || ! empty( $reform_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_subscribe"'
									. ( ! empty( $reform_anchor_icon ) ? ' icon="' . esc_attr( $reform_anchor_icon ) . '"' : '' )
									. ( ! empty( $reform_anchor_text ) ? ' title="' . esc_attr( $reform_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_subscribe_inner
	<?php
	if ( reform_get_theme_option( 'front_page_subscribe_fullheight' ) ) {
		echo ' reform-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$reform_css      = '';
			$reform_bg_mask  = reform_get_theme_option( 'front_page_subscribe_bg_mask' );
			$reform_bg_color_type = reform_get_theme_option( 'front_page_subscribe_bg_color_type' );
			if ( 'custom' == $reform_bg_color_type ) {
				$reform_bg_color = reform_get_theme_option( 'front_page_subscribe_bg_color' );
			} elseif ( 'scheme_bg_color' == $reform_bg_color_type ) {
				$reform_bg_color = reform_get_scheme_color( 'bg_color', $reform_scheme );
			} else {
				$reform_bg_color = '';
			}
			if ( ! empty( $reform_bg_color ) && $reform_bg_mask > 0 ) {
				$reform_css .= 'background-color: ' . esc_attr(
					1 == $reform_bg_mask ? $reform_bg_color : reform_hex2rgba( $reform_bg_color, $reform_bg_mask )
				) . ';';
			}
			if ( ! empty( $reform_css ) ) {
				echo ' style="' . esc_attr( $reform_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_subscribe_content_wrap content_wrap">
			<?php
			// Caption
			$reform_caption = reform_get_theme_option( 'front_page_subscribe_caption' );
			if ( ! empty( $reform_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_subscribe_caption front_page_block_<?php echo ! empty( $reform_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $reform_caption, 'reform_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$reform_description = reform_get_theme_option( 'front_page_subscribe_description' );
			if ( ! empty( $reform_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_subscribe_description front_page_block_<?php echo ! empty( $reform_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $reform_description ), 'reform_kses_content' ); ?></div>
				<?php
			}

			// Content
			$reform_sc = reform_get_theme_option( 'front_page_subscribe_shortcode' );
			if ( ! empty( $reform_sc ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_output front_page_section_subscribe_output front_page_block_<?php echo ! empty( $reform_sc ) ? 'filled' : 'empty'; ?>">
				<?php
					reform_show_layout( do_shortcode( $reform_sc ) );
				?>
				</div>
				<?php
			}
			?>
		</div>
	</div>
</div>
