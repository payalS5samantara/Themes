<div class="front_page_section front_page_section_about<?php
	$reform_scheme = reform_get_theme_option( 'front_page_about_scheme' );
	if ( ! empty( $reform_scheme ) && ! reform_is_inherit( $reform_scheme ) ) {
		echo ' scheme_' . esc_attr( $reform_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( reform_get_theme_option( 'front_page_about_paddings' ) );
	if ( reform_get_theme_option( 'front_page_about_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$reform_css      = '';
		$reform_bg_image = reform_get_theme_option( 'front_page_about_bg_image' );
		if ( ! empty( $reform_bg_image ) ) {
			$reform_css .= 'background-image: url(' . esc_url( reform_get_attachment_url( $reform_bg_image ) ) . ');';
		}
		if ( ! empty( $reform_css ) ) {
			echo ' style="' . esc_attr( $reform_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$reform_anchor_icon = reform_get_theme_option( 'front_page_about_anchor_icon' );
	$reform_anchor_text = reform_get_theme_option( 'front_page_about_anchor_text' );
if ( ( ! empty( $reform_anchor_icon ) || ! empty( $reform_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_about"'
									. ( ! empty( $reform_anchor_icon ) ? ' icon="' . esc_attr( $reform_anchor_icon ) . '"' : '' )
									. ( ! empty( $reform_anchor_text ) ? ' title="' . esc_attr( $reform_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_about_inner
	<?php
	if ( reform_get_theme_option( 'front_page_about_fullheight' ) ) {
		echo ' reform-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$reform_css           = '';
			$reform_bg_mask       = reform_get_theme_option( 'front_page_about_bg_mask' );
			$reform_bg_color_type = reform_get_theme_option( 'front_page_about_bg_color_type' );
			if ( 'custom' == $reform_bg_color_type ) {
				$reform_bg_color = reform_get_theme_option( 'front_page_about_bg_color' );
			} elseif ( 'scheme_bg_color' == $reform_bg_color_type ) {
				$reform_bg_color = reform_get_scheme_color( 'bg_color', $reform_scheme );
			} else {
				$reform_bg_color = '';
			}
			if ( ! empty( $reform_bg_color ) && $reform_bg_mask > 0 ) {
				$reform_css .= 'background-color: ' . esc_attr(
					1 == $reform_bg_mask ? $reform_bg_color : reform_hex2rgba( $reform_bg_color, $reform_bg_mask )
				) . ';';
			}
			if ( ! empty( $reform_css ) ) {
				echo ' style="' . esc_attr( $reform_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_about_content_wrap content_wrap">
			<?php
			// Caption
			$reform_caption = reform_get_theme_option( 'front_page_about_caption' );
			if ( ! empty( $reform_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_about_caption front_page_block_<?php echo ! empty( $reform_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $reform_caption, 'reform_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$reform_description = reform_get_theme_option( 'front_page_about_description' );
			if ( ! empty( $reform_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_about_description front_page_block_<?php echo ! empty( $reform_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $reform_description ), 'reform_kses_content' ); ?></div>
				<?php
			}

			// Content
			$reform_content = reform_get_theme_option( 'front_page_about_content' );
			if ( ! empty( $reform_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_content front_page_section_about_content front_page_block_<?php echo ! empty( $reform_content ) ? 'filled' : 'empty'; ?>">
					<?php
					$reform_page_content_mask = '%%CONTENT%%';
					if ( strpos( $reform_content, $reform_page_content_mask ) !== false ) {
						$reform_content = preg_replace(
							'/(\<p\>\s*)?' . $reform_page_content_mask . '(\s*\<\/p\>)/i',
							sprintf(
								'<div class="front_page_section_about_source">%s</div>',
								apply_filters( 'the_content', get_the_content() )
							),
							$reform_content
						);
					}
					reform_show_layout( $reform_content );
					?>
				</div>
				<?php
			}
			?>
		</div>
	</div>
</div>
