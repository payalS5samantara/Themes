<?php
/**
 * The Header: Logo and main menu
 *
 * @package REFORM
 * @since REFORM 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js<?php
	// Class scheme_xxx need in the <html> as context for the <body>!
	echo ' scheme_' . esc_attr( reform_get_theme_option( 'color_scheme' ) );
?>">

<head>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	} else {
		do_action( 'wp_body_open' );
	}
	do_action( 'reform_action_before_body' );
	?>

	<div class="<?php echo esc_attr( apply_filters( 'reform_filter_body_wrap_class', 'body_wrap' ) ); ?>" <?php do_action('reform_action_body_wrap_attributes'); ?>>

		<?php do_action( 'reform_action_before_page_wrap' ); ?>

		<div class="<?php echo esc_attr( apply_filters( 'reform_filter_page_wrap_class', 'page_wrap' ) ); ?>" <?php do_action('reform_action_page_wrap_attributes'); ?>>

			<?php do_action( 'reform_action_page_wrap_start' ); ?>

			<?php
			$reform_full_post_loading = ( reform_is_singular( 'post' ) || reform_is_singular( 'attachment' ) ) && reform_get_value_gp( 'action' ) == 'full_post_loading';
			$reform_prev_post_loading = ( reform_is_singular( 'post' ) || reform_is_singular( 'attachment' ) ) && reform_get_value_gp( 'action' ) == 'prev_post_loading';

			// Don't display the header elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ! $reform_full_post_loading && ! $reform_prev_post_loading ) {

				// Short links to fast access to the content, sidebar and footer from the keyboard
				?>
				<a class="reform_skip_link skip_to_content_link" href="#content_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'reform_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to content", 'reform' ); ?></a>
				<?php if ( reform_sidebar_present() ) { ?>
				<a class="reform_skip_link skip_to_sidebar_link" href="#sidebar_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'reform_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to sidebar", 'reform' ); ?></a>
				<?php } ?>
				<a class="reform_skip_link skip_to_footer_link" href="#footer_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'reform_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to footer", 'reform' ); ?></a>

				<?php
				do_action( 'reform_action_before_header' );

				// Header
				$reform_header_type = reform_get_theme_option( 'header_type' );
				if ( 'custom' == $reform_header_type && ! reform_is_layouts_available() ) {
					$reform_header_type = 'default';
				}
				get_template_part( apply_filters( 'reform_filter_get_template_part', "templates/header-" . sanitize_file_name( $reform_header_type ) ) );

				// Side menu
				if ( in_array( reform_get_theme_option( 'menu_side', 'none' ), array( 'left', 'right' ) ) ) {
					get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/header-navi-side' ) );
				}

				// Mobile menu
				if ( apply_filters( 'reform_filter_use_navi_mobile', true ) ) {
					get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/header-navi-mobile' ) );
				}

				do_action( 'reform_action_after_header' );

			}
			?>

			<?php do_action( 'reform_action_before_page_content_wrap' ); ?>

			<div class="page_content_wrap<?php
				if ( reform_is_off( reform_get_theme_option( 'remove_margins' ) ) ) {
					if ( empty( $reform_header_type ) ) {
						$reform_header_type = reform_get_theme_option( 'header_type' );
					}
					if ( 'custom' == $reform_header_type && reform_is_layouts_available() ) {
						$reform_header_id = reform_get_custom_header_id();
						if ( $reform_header_id > 0 ) {
							$reform_header_meta = reform_get_custom_layout_meta( $reform_header_id );
							if ( ! empty( $reform_header_meta['margin'] ) ) {
								?> page_content_wrap_custom_header_margin<?php
							}
						}
					}
					$reform_footer_type = reform_get_theme_option( 'footer_type' );
					if ( 'custom' == $reform_footer_type && reform_is_layouts_available() ) {
						$reform_footer_id = reform_get_custom_footer_id();
						if ( $reform_footer_id ) {
							$reform_footer_meta = reform_get_custom_layout_meta( $reform_footer_id );
							if ( ! empty( $reform_footer_meta['margin'] ) ) {
								?> page_content_wrap_custom_footer_margin<?php
							}
						}
					}
				}
				do_action( 'reform_action_page_content_wrap_class', $reform_prev_post_loading );
				?>"<?php
				if ( apply_filters( 'reform_filter_is_prev_post_loading', $reform_prev_post_loading ) ) {
					?> data-single-style="<?php echo esc_attr( reform_get_theme_option( 'single_style' ) ); ?>"<?php
				}
				do_action( 'reform_action_page_content_wrap_data', $reform_prev_post_loading );
			?>>
				<?php
				do_action( 'reform_action_page_content_wrap', $reform_full_post_loading || $reform_prev_post_loading );

				// Single posts banner
				if ( apply_filters( 'reform_filter_single_post_header', reform_is_singular( 'post' ) || reform_is_singular( 'attachment' ) ) ) {
					if ( $reform_prev_post_loading ) {
						if ( reform_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) != 'article' ) {
							do_action( 'reform_action_between_posts' );
						}
					}
					// Single post thumbnail and title
					$reform_path = apply_filters( 'reform_filter_get_template_part', 'templates/single-styles/' . reform_get_theme_option( 'single_style' ) );
					if ( reform_get_file_dir( $reform_path . '.php' ) != '' ) {
						get_template_part( $reform_path );
					}
				}

				// Widgets area above page
				$reform_body_style   = reform_get_theme_option( 'body_style' );
				$reform_widgets_name = reform_get_theme_option( 'widgets_above_page', 'hide' );
				$reform_show_widgets = ! reform_is_off( $reform_widgets_name ) && is_active_sidebar( $reform_widgets_name );
				if ( $reform_show_widgets ) {
					if ( 'fullscreen' != $reform_body_style ) {
						?>
						<div class="content_wrap">
							<?php
					}
					reform_create_widgets_area( 'widgets_above_page' );
					if ( 'fullscreen' != $reform_body_style ) {
						?>
						</div>
						<?php
					}
				}

				// Content area
				do_action( 'reform_action_before_content_wrap' );
				?>
				<div class="content_wrap<?php echo 'fullscreen' == $reform_body_style ? '_fullscreen' : ''; ?>">

					<?php do_action( 'reform_action_content_wrap_start' ); ?>

					<div class="content">
						<?php
						do_action( 'reform_action_page_content_start' );

						// Skip link anchor to fast access to the content from keyboard
						?>
						<a id="content_skip_link_anchor" class="reform_skip_link_anchor" href="#"></a>
						<?php
						// Single posts banner between prev/next posts
						if ( ( reform_is_singular( 'post' ) || reform_is_singular( 'attachment' ) )
							&& $reform_prev_post_loading 
							&& reform_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) == 'article'
						) {
							do_action( 'reform_action_between_posts' );
						}

						// Widgets area above content
						reform_create_widgets_area( 'widgets_above_content' );

						do_action( 'reform_action_page_content_start_text' );
