<?php
/**
 * The template to display single post
 *
 * @package REFORM
 * @since REFORM 1.0
 */

// Full post loading
$full_post_loading          = reform_get_value_gp( 'action' ) == 'full_post_loading';

// Prev post loading
$prev_post_loading          = reform_get_value_gp( 'action' ) == 'prev_post_loading';
$prev_post_loading_type     = reform_get_theme_option( 'posts_navigation_scroll_which_block', 'article' );

// Position of the related posts
$reform_related_position   = reform_get_theme_option( 'related_position', 'below_content' );

// Type of the prev/next post navigation
$reform_posts_navigation   = reform_get_theme_option( 'posts_navigation' );
$reform_prev_post          = false;
$reform_prev_post_same_cat = (int)reform_get_theme_option( 'posts_navigation_scroll_same_cat', 1 );

// Rewrite style of the single post if current post loading via AJAX and featured image and title is not in the content
if ( ( $full_post_loading 
		|| 
		( $prev_post_loading && 'article' == $prev_post_loading_type )
	) 
	&& 
	! in_array( reform_get_theme_option( 'single_style' ), array( 'style-6' ) )
) {
	reform_storage_set_array( 'options_meta', 'single_style', 'style-6' );
}

do_action( 'reform_action_prev_post_loading', $prev_post_loading, $prev_post_loading_type );

get_header();

while ( have_posts() ) {

	the_post();

	// Type of the prev/next post navigation
	if ( 'scroll' == $reform_posts_navigation ) {
		$reform_prev_post = get_previous_post( $reform_prev_post_same_cat );  // Get post from same category
		if ( ! $reform_prev_post && $reform_prev_post_same_cat ) {
			$reform_prev_post = get_previous_post( false );                    // Get post from any category
		}
		if ( ! $reform_prev_post ) {
			$reform_posts_navigation = 'links';
		}
	}

	// Override some theme options to display featured image, title and post meta in the dynamic loaded posts
	if ( $full_post_loading || ( $prev_post_loading && $reform_prev_post ) ) {
		reform_sc_layouts_showed( 'featured', false );
		reform_sc_layouts_showed( 'title', false );
		reform_sc_layouts_showed( 'postmeta', false );
	}

	// If related posts should be inside the content
	if ( strpos( $reform_related_position, 'inside' ) === 0 ) {
		ob_start();
	}

	// Display post's content
	get_template_part( apply_filters( 'reform_filter_get_template_part', 'templates/content', 'single-' . reform_get_theme_option( 'single_style' ) ), 'single-' . reform_get_theme_option( 'single_style' ) );

	// If related posts should be inside the content
	if ( strpos( $reform_related_position, 'inside' ) === 0 ) {
		$reform_content = ob_get_contents();
		ob_end_clean();

		ob_start();
		do_action( 'reform_action_related_posts' );
		$reform_related_content = ob_get_contents();
		ob_end_clean();

		if ( ! empty( $reform_related_content ) ) {
			$reform_related_position_inside = max( 0, min( 9, reform_get_theme_option( 'related_position_inside' ) ) );
			if ( 0 == $reform_related_position_inside ) {
				$reform_related_position_inside = mt_rand( 1, 9 );
			}

			$reform_p_number         = 0;
			$reform_related_inserted = false;
			$reform_in_block         = false;
			$reform_content_start    = strpos( $reform_content, '<div class="post_content' );
			$reform_content_end      = strrpos( $reform_content, '</div>' );

			for ( $i = max( 0, $reform_content_start ); $i < min( strlen( $reform_content ) - 3, $reform_content_end ); $i++ ) {
				if ( $reform_content[ $i ] != '<' ) {
					continue;
				}
				if ( $reform_in_block ) {
					if ( strtolower( substr( $reform_content, $i + 1, 12 ) ) == '/blockquote>' ) {
						$reform_in_block = false;
						$i += 12;
					}
					continue;
				} else if ( strtolower( substr( $reform_content, $i + 1, 10 ) ) == 'blockquote' && in_array( $reform_content[ $i + 11 ], array( '>', ' ' ) ) ) {
					$reform_in_block = true;
					$i += 11;
					continue;
				} else if ( 'p' == $reform_content[ $i + 1 ] && in_array( $reform_content[ $i + 2 ], array( '>', ' ' ) ) ) {
					$reform_p_number++;
					if ( $reform_related_position_inside == $reform_p_number ) {
						$reform_related_inserted = true;
						$reform_content = ( $i > 0 ? substr( $reform_content, 0, $i ) : '' )
											. $reform_related_content
											. substr( $reform_content, $i );
					}
				}
			}
			if ( ! $reform_related_inserted ) {
				if ( $reform_content_end > 0 ) {
					$reform_content = substr( $reform_content, 0, $reform_content_end ) . $reform_related_content . substr( $reform_content, $reform_content_end );
				} else {
					$reform_content .= $reform_related_content;
				}
			}
		}

		reform_show_layout( $reform_content );
	}

	// Comments
	do_action( 'reform_action_before_comments' );
	comments_template();
	do_action( 'reform_action_after_comments' );

	// Related posts
	if ( 'below_content' == $reform_related_position
		&& ( 'scroll' != $reform_posts_navigation || (int)reform_get_theme_option( 'posts_navigation_scroll_hide_related', 0 ) == 0 )
		&& ( ! $full_post_loading || (int)reform_get_theme_option( 'open_full_post_hide_related', 1 ) == 0 )
	) {
		do_action( 'reform_action_related_posts' );
	}

	// Post navigation: type 'scroll'
	if ( 'scroll' == $reform_posts_navigation && ! $full_post_loading ) {
		?>
		<div class="nav-links-single-scroll"
			data-post-id="<?php echo esc_attr( get_the_ID( $reform_prev_post ) ); ?>"
			data-post-link="<?php echo esc_attr( get_permalink( $reform_prev_post ) ); ?>"
			data-post-title="<?php the_title_attribute( array( 'post' => $reform_prev_post ) ); ?>"
			data-cur-post-link="<?php echo esc_attr( get_permalink() ); ?>"
			data-cur-post-title="<?php the_title_attribute(); ?>"
			<?php do_action( 'reform_action_nav_links_single_scroll_data', $reform_prev_post ); ?>
		></div>
		<?php
	}
}

get_footer();
