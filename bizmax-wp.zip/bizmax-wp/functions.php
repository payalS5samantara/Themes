<?php
/**
 * Bizmax functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package bizmax
 */


if ( ! function_exists( 'bizmax_wp_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function bizmax_wp_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on bizmax, use a find and replace
		 * to change 'bizmax-wp' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'bizmax-wp', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

	

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// Theme Supports 
		add_image_size( 'bizmax-team-thumb', '354', '455', true );
		add_image_size( 'bizmax-blog-thumb', '355', '345', true );
		add_image_size( 'bizmax-blog-single-thumb', '738', '400', true );
		
		
			// Register Nav Menu
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'bizmax-wp' ),
			'menu-2' => esc_html__( 'Mobile', 'bizmax-wp' ),
		) );
		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'bizmax_wp_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );
      
		
		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
		
		// Enable supports for gutenberg blocks
		add_theme_support( 'align-wide' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'wp-block-styles' );
	}
endif;
add_action( 'after_setup_theme', 'bizmax_wp_setup' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function bizmax_wp_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Blog Sidebar', 'bizmax-wp' ),
		'id'            => 'bizmax-blog-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'bizmax-wp' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Blog Archive Sidebar', 'bizmax-wp' ),
		'id'            => 'bizmax-blog-archive-sidebar',
		'description'   => esc_html__( 'Add archive blog widgets here.', 'bizmax-wp' ),
		'before_widget' => '<div id="%1$s" class="single-widget widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Blog Single Sidebar', 'bizmax-wp' ),
		'id'            => 'bizmax-blog-single-sidebar',
		'description'   => esc_html__( 'Add single blog widgets here.', 'bizmax-wp' ),
		'before_widget' => '<div id="%1$s" class="single-widget widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 1', 'bizmax-wp' ),
		'id'            => 'bizmax-footer-1',
		'description'   => esc_html__( 'Add footer widget here.', 'bizmax-wp' ),
		'before_widget' => '<div id="%1$s" class="single-widget f-link widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 2', 'bizmax-wp' ),
		'id'            => 'bizmax-footer-2',
		'description'   => esc_html__( 'Add footer widget here.', 'bizmax-wp' ),
		'before_widget' => '<div id="%1$s" class="single-widget f-link footer-2-col-2 widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 3', 'bizmax-wp' ),
		'id'            => 'bizmax-footer-3',
		'description'   => esc_html__( 'Add footer widget here.', 'bizmax-wp' ),
		'before_widget' => '<div id="%1$s" class="single-widget f-link footer-2-col-2 widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'bizmax_wp_widgets_init' );


/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/comment-template.php';
require get_template_directory() . '/inc/google-fonts.php';
require get_template_directory() . '/inc/import-demo-files.php';
require get_template_directory() . '/inc/scripts-styles.php';
require get_template_directory() . '/inc/tgm/recommended-plugins.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/metabox-and-options/metabox-option.php';

/**
 * CS Framework Initial.
 */

if ( ! function_exists( 'bizmax_wp_option' ) ) {
	function bizmax_wp_option( $option = '', $default = null ) {
	  $options = get_option( 'bizmax_wp_options' ); // Attention: Set your unique id of the framework
	  return ( isset( $options[$option] ) ) ? $options[$option] : $default;
	}
  }


if(! class_exists( 'CSF' ) ){
	function bizmax_wp_default_google_font() {
	   wp_enqueue_style( 'bizmax-default-style', get_template_directory_uri() . '/assets/css/bizmax-default.css', array(), '1.0' );
	}
	add_action( 'wp_enqueue_scripts', 'bizmax_wp_default_google_font' );
}


/* CS Framework Setup */
 if(function_exists('csf_init') || class_exists( 'CSF' ) ){
    require get_template_directory() . '/inc/custom-style.php';
 }