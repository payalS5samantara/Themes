<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package bizmax
 */

get_header();

	$search_bc_bg = bizmax_wp_option('search_bc_bg');
	if($search_bc_bg){
		$blog_search_bc_src = wp_get_attachment_image_src($search_bc_bg['id'], 'full', false);
	}
	
	$breadcrumb_background = bizmax_wp_option('breadcrumb_background');
	if($breadcrumb_background){
		$breadcrumb_background_src = wp_get_attachment_image_src($breadcrumb_background['id'], 'full', false);
	}

	if(have_posts()){
		$blog_row_resize = 'grid';
	} else {
		$blog_row_resize = 'no-grid';
	}
	
	if(is_active_sidebar( 'bizmax-blog-sidebar' )){
		$blog_sidebar_column = 'col-lg-8';
	} else {
		$blog_sidebar_column = 'col-lg-10 offset-lg-1 col-md-10 offset-md-1';
	}
?>

	<!-- Breadcrumbs -->
	<div class="cs_page_header position-relative background-filled d-flex align-items-center justify-content-between" 
		<?php if(!empty($blog_search_bc_src)) :?>
		data-src="<?php echo esc_url($blog_search_bc_src[0]); ?>"
		<?php elseif(!empty($breadcrumb_background_src)) :?>
		data-src="<?php echo esc_url($breadcrumb_background_src[0]); ?>"
		<?php endif;?>>
		<div class="container position-relative z-index-1">
			<nav aria-label="breadcrumb" class="breadcrumb-nav cs_fs_18 cs_mb_5">
				<?php if (function_exists('bcn_display')) bcn_display(); ?>
			</nav>
			<h1 class="cs_fs_48 cs_fs_lg_36 text-white m-0">
			<?php
			/* translators: %s: search query. */
			printf( esc_html__( 'Search Results: %s', 'bizmax-wp' ), '<span>' . get_search_query() . '</span>' );
			?>
			</h1>
		</div>
		<div class="position-absolute end-0 bottom-0">
			<svg width="660" height="497" viewBox="0 0 660 497" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M240 0H660L430 497H0L240 0Z" fill="url(#paint0_linear_81_9510)"/>
				<defs>
				<linearGradient id="paint0_linear_81_9510" x1="330" y1="78.2497" x2="375.052" y2="780.743" gradientUnits="userSpaceOnUse">
				<stop stop-color="white" stop-opacity="0" offset="none"/>
				<stop offset="0.9999" stop-color="#D9D9D9" stop-opacity="0.35"/>
				<stop offset="1" stop-color="#222121" stop-opacity="0"/>
				<stop offset="1" stop-color="#222121" stop-opacity="0"/>
				</linearGradient>
				</defs>
			</svg> 
		</div>      
	</div>
	<!--/ End Breadcrumbs -->


	<div class="bizmax-internal-area news-area section-bg search-page bizmax-blog-main-section">
		<div class="container">
			<div class="row">
				<div class="<?php echo $blog_sidebar_column;?> col-12">
					<div class="bizmax-page-content bizmax-blog-main-section__archive">
						<div class="row <?php echo $blog_row_resize; ?>">
							<?php if ( have_posts() ) : ?>

								<?php
								/* Start the Loop */
								while ( have_posts() ) :
									the_post();

									/**
									 * Run the loop for the search to output the results.
									 * If you want to overload this in a child theme then include a file
									 * called content-search.php and that will be used instead.
									 */
									get_template_part( 'template-parts/content', 'search' );

								endwhile;

								else :
									get_template_part( 'template-parts/content', 'none' );

								endif;
							?>
						</div>
						<div class="row">
							<div class="col-12">
								<!-- Start Pagination -->
								<div class="pagination-main">
									<?php if (function_exists("bizmax_wp_pagination"))
										{
											bizmax_wp_pagination();
										}  
									?>
								</div>
								<!--/ End Pagination -->
							</div>
						</div>	
					</div>
				</div>
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>

<?php
get_footer();
