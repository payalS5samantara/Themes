=== sorex  ===
Contributors: laralink
Author URI: 
Requires at least: 4.0
Tested up to: 6.6
Requires at least: 4.0
Requires PHP: 5.6
Stable tag: 1.0.0
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Tags: grid-layout, blog, news, grid-layout, two-columns, right-sidebar, custom-background, custom-logo, custom-menu, featured-images, footer-widgets,  sticky-post, theme-options, threaded-comments,  translation-ready

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Corporate And Consulting Business WordPress Theme

== Frequently Asked Questions ==

= How to install sorex theme=
1. Login your WordPress dashboard.
2. Go to "Appearance" -> "Theme" and click on "Add New" button.
3. Click on "Upload Theme" button and choose the theme's zip file you have downloaded.
4. Click on "Install Now" button.
5. Activate the theme.
6. Now go to "Appearance" -> "Customize" to configure theme options.

== Changelog ==

= 1.0.0 - July 20 2023 =
* Initial release

== Credits ==
All the theme files, scripts and images are licensed under GPLv2 license

sorex theme uses:

*	Font Awesome 6.2 by @davegandy
	License: http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
	Source: http://fontawesome.io

*	Bootstrap v5 by twitter, inc
	Licensed under MIT: https://github.com/twbs/bootstrap/blob/master/LICENSE 
	Source: https://getbootstrap.com

*	Animate CSS 3.7.2 By daniel eden 
	Licensed under MIT: http://opensource.org/licenses/MIT
	Source: https://daneden.github.io/animate.css/

*	Magnific Popup - v1.1.0 By dmitry semenov;
	License: https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE
	Source: http://dimsemenov.com/plugins/magnific-popup/
	
*	Underscores by automattic inc.
	License: https://www.gnu.org/licenses/gpl-2.0.html
	Source: https://underscores.me/
	
*  	TGM-Plugin-Activation - v2.6.1 By thomas griffin
	License: http://opensource.org/licenses/gpl-2.0.php
	Source: https://github.com/TGMPA/TGM-Plugin-Activation