<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bizmax
 */
 
	if(get_post_meta($post->ID, 'bizmax_wp_blog_options', true)){
		$single_blog_meta = get_post_meta($post->ID, 'bizmax_wp_blog_options', true);
	}else{
		$single_blog_meta = array();
	}
	
	if(array_key_exists('enable_featured_image', $single_blog_meta)){
		$enable_featured_image = $single_blog_meta['enable_featured_image'];
	} else {
		$enable_featured_image = true;
	}
	
	if(array_key_exists('featured_image_upload', $single_blog_meta)){
		$featured_image_upload = $single_blog_meta['featured_image_upload'];
	} else {
		$featured_image_upload = '';
	}
	if($featured_image_upload){
		$image_logo_src = wp_get_attachment_image_src($featured_image_upload['id'], 'full', false);
	}
	$show_author_name = bizmax_wp_option('single_show_author_name');
	$show_post_date = bizmax_wp_option('single_show_post_date');
	$show_post_comment = bizmax_wp_option('single_show_post_comment');

?>

<!-- Single News -->
<div class="cs_post cs_style_1 bg-white shadow-sm cs_mb_30 bizmax-blog-main-section__blog">
	<?php if(has_post_thumbnail() && $enable_featured_image == true && empty($image_logo_src)) : ?>
		<?php the_post_thumbnail('bizmax-blog-single-thumb'); ?>
	<?php else : ?>
		<?php if( !empty ($image_logo_src)) :?>
		<img src="<?php echo esc_url($image_logo_src[0]); ?>" alt="<?php esc_attr_e('Featured Image','bizmax-wp');?>">
		<?php endif;?>
	<?php endif;?>
	<div class="cs_pl_40 cs_pr_40 cs_pt_40 cs_pb_40 cs_pl_lg_25 cs_pr_lg_25 cs_pt_lg_25 cs_pb_lg_25">
		
	<ul class="cs_post_meta d-flex flex-wrap cs_fs_12 p-0 cs_mb_20">
		<?php if ($show_author_name == true) : ?>
		<li>
			<span><i class="fas fa-user"></i> <?php esc_html_e('By','bizmax-wp');?> </span> 
			<a href=""><?php bizmax_wp_posted_by(); ?></a>
		</li>
		<?php endif;?>
		<?php if ($show_post_date == true) : ?>
		<li>
			<span><i class="fas fa-calendar-alt"></i><?php echo get_the_date(); ?></span> 
		</li>
		<?php endif;?>
		<?php if ($show_post_comment == true) : ?>
		<li>
			<span><i class="fas fa-comment-dots"></i></span> 
			<a href=""><?php comments_number(); ?> </a>
		</li>
		<?php endif;?>
	</ul>

	<?php the_content(); ?>

	</div>
		
	<?php wp_link_pages( array(
		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'bizmax-wp' ),
		'after'  => '</div>',
	) );
	?>
	
</div>

<div class="d-flex justify-content-between align-items-center bg-gray cs_pt_25 cs_pb_25 cs_pl_40 cs_pl_lg_25 cs_pr_40 cs_pr_lg_25 flex-wrap cs_row_gap_15 cs_column_gap_15 cs_mb_40">
		<div class="cs_post_details-meta-tag">
		<h4 class="cs_sidebar_widget_title"><?php echo esc_html_e('Tags :', 'bizmax-wp');?></h4>
		<?php if(has_tag()) :?>
			<?php 
				$post_tags = get_the_tags();
				if ( ! empty( $post_tags ) ) {
					echo '<div class="tagcloud">';
					foreach( $post_tags as $post_tag ) {
						echo '<a class="tag-cloud-link" href="' . get_tag_link( $post_tag ) . '">' . $post_tag->name . '</a>';
					}
					echo '</div>';
				}   
				?>
		<?php endif;?>
		</div>
	</div>


<div class="blog-post-tag">
		<div class="row">
			<?php if(has_tag()) :?>
			<div class="col-12">
				<div class="share-tag post-tag">
					<h5></h5>
					
				</div>
			</div>
			<?php endif;?>
		</div>
	</div>

