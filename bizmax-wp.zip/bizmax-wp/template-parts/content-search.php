<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bizmax
 */
	$show_author_name = bizmax_wp_option('archive_show_author_name');
	$show_post_date = bizmax_wp_option('archive_show_post_date');
	$show_post_comment = bizmax_wp_option('archive_show_post_comment');
	$featured_img_url = get_the_post_thumbnail_url($post->ID, 'full'); 
	$post_content = get_the_content();

?>

<div class="col-lg-6 col-md-6 col-12 blog-single-column grid-item">
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="cs_post cs_style_1 bg-white shadow-sm">
			<?php if (has_post_thumbnail()) :?>
			<a href="<?php the_permalink(); ?>" class="cs_post_thumb d-block position-relative overflow-hidden">
				<div class="cs_post_thumb-in cs_transition_5 background-filled h-100 w-100" data-src="<?php echo $featured_img_url;?>"></div>
			</a>
			<?php endif;?>
			<div class="cs_post_in">
			<div class="cs_post_info cs_pl_33 cs_pr_33 cs_pt_40 cs_pb_40">
				<ul class="cs_post_meta d-flex flex-wrap cs_fs_12 p-0 cs_mb_16">
				<?php if ($show_author_name == true) : ?>
					<li>
						<span><i class="fas fa-user"></i> <?php esc_html_e('By','bizmax-wp');?>  </span> 
						<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><?php echo get_the_author(); ?></a>
					</li>
				<?php endif;?>
				<?php if ($show_post_date == true) : ?>
					<li>
						<span><i class="fas fa-calendar-alt"></i></span> 
						<?php bizmax_wp_posted_on(); ?>
					</li>
				<?php endif;?>
				<?php if ($show_post_comment == true) : ?>
					<li>
						<span><i class="fas fa-comment-dots"></i></span> 
						<?php echo get_comments_number();?> <?php esc_html_e('comments','bizmax-wp');?>
					</li>
				<?php endif;?>
				</ul>
				<h2 class="cs_post_title cs_lh_base cs_fs_20 cs_fs_lg_18 cs_mb_10"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<div class="cs_post_subtitle"><?php echo wp_trim_words( $post_content, '22');?></div>
			</div>
			<a href="<?php the_permalink(); ?>" class="cs_post_btn d-flex justify-content-between align-items-center cs_pl_40 cs_pr_40 cs_pb_10 cs_pt_10">
				<span class="cs_post_btn-text"><?php esc_html_e('Read More','bizmax-wp');?></span>
				<div class="cs_post_btn-icon d-flex cs_transition_4">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M11.9999 0.224976C6.52011 0.224976 1.63131 4.16368 0.485006 9.52707C-0.0876941 12.207 0.298106 15.0567 1.57581 17.4816C2.80551 19.8153 4.82151 21.7014 7.23351 22.7703C9.74241 23.8824 12.6227 24.0762 15.2597 23.3178C17.8037 22.5864 20.0594 20.9811 21.5951 18.8262C24.806 14.3211 24.3767 7.99288 20.5991 3.95608C18.3851 1.59028 15.2405 0.224976 11.9999 0.224976ZM17.6486 12.6291L14.4386 15.9165C13.6259 16.749 12.3413 15.4878 13.1507 14.6592L14.7704 13.0005H7.09461C6.54951 13.0005 6.09471 12.5454 6.09471 12.0006C6.09471 11.4558 6.54981 11.0007 7.09461 11.0007H14.732L13.0802 9.34918C12.2594 8.52838 13.532 7.25548 14.3528 8.07628L17.6411 11.3643C17.9897 11.7126 17.993 12.2766 17.6486 12.6291Z" fill="currentColor"/>
				</svg>  
				</div>                
			</a>
			</div>
		</div>
	</article> <!-- #post-<?php the_ID(); ?> -->
</div>