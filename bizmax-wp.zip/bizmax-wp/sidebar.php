<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bizmax
 */

if ( ! is_active_sidebar( 'bizmax-blog-sidebar' ) ) {
	return;
}
?>

<div class="col-lg-4 col-12">
	<aside id="secondary" class="sidebar-main">
		<?php dynamic_sidebar( 'bizmax-blog-sidebar' ); ?>
	</aside><!-- #secondary -->
</div>