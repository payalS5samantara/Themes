(function ($) {
	"use strict";

	if ($('#smooth-wrapper').length > 0) {
		gsap.registerPlugin(ScrollSmoother,ScrollTrigger);
		let smoother = ScrollSmoother.create({
			wrapper : '#smooth-wrapper',
			content : '#smooth-content',
			smooth: 1,
			effects: true        
		})
   }

   if ($('.title-anim').length > 0) {
		// 25. Title Animation
		let splitTitleLines = gsap.utils.toArray(".title-anim");
		splitTitleLines.forEach(splitTextLine => {
			const tl = gsap.timeline({
			scrollTrigger: {
				trigger: splitTextLine,
				start: 'top 90%',
				end: 'bottom 60%',
				scrub: false,
				markers: false,
				toggleActions: 'play none none none'
			}
			});

			const itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
			gsap.set(splitTextLine, { perspective: 300});
			itemSplitted.split({ type: "lines" })
			tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -60, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
		});	
    }

	if ($('.char-anim').length > 0) {
		// 25. Title Animation
		let char_come = gsap.utils.toArray(".char-anim");
		char_come.forEach(splitTextLine => {
			const tl = gsap.timeline({
			scrollTrigger: {
				trigger: splitTextLine,
				start: 'top 90%',
				end: 'bottom 60%',
				scrub: false,
				markers: false,
				toggleActions: 'play none none none'
			}
			});

			const itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
			gsap.set(splitTextLine, { perspective: 300});
			itemSplitted.split({ type: "chars, words"})
			tl.from(itemSplitted.chars, 
				{
					duration: 1,
					x: 100,
					autoAlpha: 0,
					stagger: 0.05 
				});
		});	
	}

	if ($('.char-anim-2').length > 0) {
		// 25. Title Animation
		let char_come = gsap.utils.toArray(".char-anim-2");
		char_come.forEach(splitTextLine => {
			const tl = gsap.timeline({
			scrollTrigger: {
				trigger: splitTextLine,
				start: 'top 90%',
				end: 'bottom 60%',
				scrub: false,
				markers: false,
				toggleActions: 'play none none none'
			}
			});

			const itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
			gsap.set(splitTextLine, { perspective: 300});
			itemSplitted.split({ type: "chars, words"})
			tl.from(itemSplitted.chars, 
				{
					duration: 1.2,
					opacity: 0,
					scale: 0,
					y: 60,
					rotationX: 180,
					transformOrigin: "0% 30% -30%",
					stagger: 0.02
				});
		});	
	}

	
})(jQuery);