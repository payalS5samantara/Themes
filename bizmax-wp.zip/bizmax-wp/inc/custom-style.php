<?php

function bizmax_wp_dynamic_style() {
	$bizmax_wp_custom_css = ''; // define variable before if statements
	wp_enqueue_style('bizmax-custom-style', get_template_directory_uri() . '/assets/css/theme-style.css', array(), '1.0.0', 'all' );
	
	// Google Fonts Load
	$body_font_array	=	bizmax_wp_option('body_font');
	$heading_font_array	    =	bizmax_wp_option('heading_font');
	$body_other_font_array	    =	bizmax_wp_option('body_other_font');
	
	if(!empty($body_font_array)){
		$bizmax_wp_custom_css = '
			body{
				font-family: '.esc_html($body_font_array['font-family']).', sans-serif; 
				font-weight: '.esc_html($body_font_array['font-weight']).'; 
			}
		';
	}
	
	if(!empty($heading_font_array)){
        $bizmax_wp_custom_css .= '
          h1,h2,h3,h4,h5,h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a {
                font-family: "'.esc_html($heading_font_array['font-family']).'", sans-serif !important;
                font-weight: '.esc_html($heading_font_array['font-weight']).'  !important;
			}
		';
	}

	if(!empty($body_other_font_array)){
        $bizmax_wp_custom_css .= '
		.cs_nav .cs_nav_list a {
                font-family: "'.esc_html($body_other_font_array['font-family']).'", sans-serif !important;
                font-weight: '.esc_html($body_other_font_array['font-weight']).'  !important;
			}
		';
	}
	
	
	// Box BG Options
	$body_bg_color	=	bizmax_wp_option('body_bg_color');
	$body_bg	=	bizmax_wp_option('body_bg');
	$footer_bg  =   bizmax_wp_option('footer_bg');
	$footer_heading_color	=	bizmax_wp_option('footer_heading_color');
	$footer_title_color	=	bizmax_wp_option('footer_title_color');
	$footer_text_color	=	bizmax_wp_option('footer_text_color');
	$primary_color	=	bizmax_wp_option('primary_color');
	
	
	if(!empty($footer_bg)) {
		$bizmax_wp_custom_css .='
			
		';
	}
	if(!empty($footer_heading_color)) {
		$bizmax_wp_custom_css .='
		.footer .single-widget .widget-title, .footer .wp-block-heading,
		.footer .widget_nav_menu ul li a, .footer .widget_nav_menu ul li{
			color: '.esc_attr($footer_heading_color).' !important;
		}
			
		';
	}
	if(!empty($footer_title_color)) {
		$bizmax_wp_custom_css .='
		.footer-news-list li .wp-block-latest-posts__post-title, .footer-news-list li a,
		.wp-block-heading.footer-inside-heading{
			color: '.esc_attr($footer_title_color).' !important;
		}
			
		';
	}
	if(!empty($footer_text_color)) {
		$bizmax_wp_custom_css .='
			.footer p{color: '.esc_attr($footer_text_color).'}
			
		';
	}
	
	// Theme Primary Colors
	if(!empty($primary_color)){
		$bizmax_wp_custom_css .='
			:root {
              --accent-color: '.esc_attr($primary_color).'
            }
			
		';
	}
	
	
	wp_add_inline_style('bizmax-custom-style', $bizmax_wp_custom_css);	
}
add_action('wp_enqueue_scripts', 'bizmax_wp_dynamic_style');