<?php
function bizmax_wp_import_demo_files() {
    return array(
        array(
            'import_file_name'             => esc_html__('Bizmax Demo Import', 'bizmax-wp'),

            'local_import_file'            => __DIR__ . '/demo-data/bizmax-demo-data.xml',

            'local_import_widget_file'     => __DIR__ . '/demo-data/bizmax-widgets.wie',

            'local_import_customizer_file' => __DIR__ . '/demo-data/bizmax-export.dat',

            'import_notice'                => esc_html__( 'After import demo, just set static homepage from settings > reading, Set menus. You will be done! :-)', 'bizmax-wp' ),
        )
    );
}
add_filter( 'pt-ocdi/import_files', 'bizmax_wp_import_demo_files' );
