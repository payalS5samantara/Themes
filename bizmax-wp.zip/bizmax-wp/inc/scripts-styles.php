<?php
/**
 * Enqueue scripts and styles.
 */
function bizmax_wp_scripts() {
	
	$theme_animation	=	bizmax_wp_option('theme_animation');
	wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.min.css', array(), '1.0' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '5.0.2' );
	wp_enqueue_style( 'fontawesome-pro', get_template_directory_uri() . '/assets/css/font-awesome-pro.css', array(), '5.15.4' );
	wp_enqueue_style( 'meanmenu', get_template_directory_uri() . '/assets/css/meanmenu.css', array(), '2.0.7' );
	wp_enqueue_style( 'bizmax-reset', get_template_directory_uri() . '/assets/css/reset.css', array(), '1.0' );
	wp_enqueue_style( 'bizmax-style', get_stylesheet_uri() );
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '5.0.2', true );
	
	wp_enqueue_script( 'meanmenu', get_template_directory_uri() . '/assets/js/meanmenu.js', array('jquery'), '1.0.1', true );
    wp_enqueue_script( 'jquery-masonry' );
	wp_enqueue_script( 'bizmax-active', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0', true );

	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	$bizmax_wp_custom_css = bizmax_wp_option('bizmax_wp_custom_css');
	$bizmax_wp_head_scripts = bizmax_wp_option('bizmax_wp_head_scripts');
	$bizmax_wp_body_scripts = bizmax_wp_option('bizmax_wp_body_scripts');
	
	wp_add_inline_style('bizmax-style', $bizmax_wp_custom_css);
	wp_add_inline_script('jquery-migrate', $bizmax_wp_head_scripts);
	wp_add_inline_script('bizmax-active', $bizmax_wp_body_scripts);
}
add_action( 'wp_enqueue_scripts', 'bizmax_wp_scripts' );


function bizmax_wp_gutenberg_styles() {
	wp_enqueue_style( 'bizmax-gutenberg', get_theme_file_uri( '/assets/css/gutenberg.css' ), false, '1.0', 'all' );
}
add_action( 'enqueue_block_editor_assets', 'bizmax_wp_gutenberg_styles' );

