<?php
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 *
 * It is expected that theme authors would copy and paste this code into their
 * functions.php file, and amend to suit.
 *
 * @see http://tgmpluginactivation.com/configuration/ for detailed documentation.
 *
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 * @version    2.6.1 for parent theme sorex for publication on ThemeForest
 * @author     Thomas Griffin, Gary Jones, Juliette Reinders Folmer
 * @copyright  Copyright (c) 2011, Thomas Griffin
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/TGMPA/TGM-Plugin-Activation
 */

/**
 * Include the TGM_Plugin_Activation class.
 *
 * Depending on your implementation, you may want to change the include call:
 *
 * Parent Theme:
 * require_once get_template_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Child Theme:
 * require_once get_stylesheet_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Plugin:
 * require_once dirname( __FILE__ ) . '/path/to/class-tgm-plugin-activation.php';
 */
require_once get_template_directory() . '/inc/tgm/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'bizmax_wp_register_required_plugins' );

/**
 * Register the required plugins for this theme.
 *
 * In this example, we register five plugins:
 * - one included with the TGMPA library
 * - two from an external source, one from an arbitrary source, one from a GitHub repository
 * - two from the .org repo, where one demonstrates the use of the `is_callable` argument
 *
 * The variables passed to the `tgmpa()` function should be:
 * - an array of plugin arrays;
 * - optionally a configuration array.
 * If you are not changing anything in the configuration array, you can remove the array and remove the
 * variable from the function call: `tgmpa( $plugins );`.
 * In that case, the TGMPA default settings will be used.
 *
 * This function is hooked into `tgmpa_register`, which is fired on the WP `init` action on priority 10.
 */
function bizmax_wp_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// sorex Toolkit.
		array(
			'name'               => 'Bizmax Toolkit',
			'slug'               => 'bizmax-toolkit',
			'source'             => get_template_directory() . '/inc/plugins/bizmax-toolkit.zip',
			'required'           => true,
			'version'            => '1.0.0', 
			'force_activation'   => true, 
			'force_deactivation' => true,
		),
		
		// Elementor Website Builder
		array(
			'name'               => 'Elementor Website Builder',
			'slug'               => 'elementor',
			'required'           => true,
			'version'            => '3.23.4', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
		// Codester Framework.
		array(
			'name'               => 'Codestar Framework',
			'slug'               => 'cs-framework',
			'source'             => get_template_directory() . '/inc/plugins/codestar-framework.zip',
			'required'           => true,
			'version'            => '2.2.9', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
		// Elementor Website Builder
		array(
			'name'               => 'Elementor Header & Footer Builder',
			'slug'               => 'header-footer-elementor',
			'required'           => true,
			'version'            => '1.6.40', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
			
		// Breadcrumb Nav.
		array(
			'name'               => 'X Addons for Elementor',
			'slug'               => 'x-addons-elementor',
			'required'           => true,
			'version'            => '1.0.11', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
		
		// Breadcrumb Nav.
		array(
			'name'               => 'Breadcrumb NavXT',
			'slug'               => 'breadcrumb-navxt',
			'required'           => true,
			'version'            => '7.3.0', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
		// Contact Form 7.
		array(
			'name'               => 'Contact Form 7',
			'slug'               => 'contact-form-7',
			'required'           => true,
			'version'            => '5.9.8', 
			'force_activation'   => false, 
			'force_deactivation' => false,
		),
		
		array(
			'name'      => 'MC4WP: Mailchimp for WordPress',
			'slug'      => 'mailchimp-for-wp',
			'version'  	=> '4.9.15',
			'required'  => false,
		),
		
		array(
			'name'      => 'One Click Demo Import',
			'slug'      => 'one-click-demo-import',
			'version'   => '3.2.1',
			'required'  => false,
		),
		
		array(
			'name'      => 'Loco Translate',
			'slug'      => 'loco-translate',
			'version'   => '2.6.11',
			'required'  => true,
		),

	);

	$config = array(
		'id'           => 'bizmax-wp',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

		
	);

	tgmpa( $plugins, $config );
}
