<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
// -----------------------------------------
// All Breadcrumb Metabox Options                    -
// -----------------------------------------

if( class_exists( 'CSF' ) ) {

    // Set a unique slug-like ID
    $bizmax_wp_breadcrumb_options = 'bizmax_wp_breadcrumb_options';
  
    // Create a metabox
    CSF::createMetabox( $bizmax_wp_breadcrumb_options, array(
	  'title'			=> esc_html__('Breadcrumb Settings', 'bizmax-wp'),
      'post_type' => array('page', 'post'),
      'priority' => 'low',
    ) );
  
    // Create a section
    CSF::createSection( $bizmax_wp_breadcrumb_options, array(
      'title'  => 'Breadcrumb Options',
      'fields' => array(
			array(
				'id'    => 'enable_breadcrumb',
				'type'  => 'switcher',
				'title' => esc_html__('Enable breadcrumb?', 'bizmax-wp'),
				'default' => true,
				'desc' => esc_html__('if you want to enable title, please slect yes', 'bizmax-wp'),
			),
			array(
				'id'       => 'pagebc_styles',
				'type'     => 'select',
				'title'    => esc_html__('Breadcrumb Style', 'bizmax-wp' ),
				'options'  => array(
					'default'   => esc_attr__('Default', 'bizmax-wp'),
					'style2'   => esc_attr__('Style V2', 'bizmax-wp'),
				),
				'default'  => 'default',
				'desc' => esc_html__('Select breadcrumb style', 'bizmax-wp'),
				'dependency'   => array( 'enable_breadcrumb', '==', 'true' ),
			), 
			array(
				'id'    => 'bc_custom_title',
				'type'  => 'text',
				'title' => esc_html__('Custom Title?', 'bizmax-wp'),
				'dependency'   => array( 'enable_breadcrumb', '==', 'true' ),
				'desc' => esc_html__('Type breacrumb custom title, This will replace current title.', 'bizmax-wp'),
			),
      	)
    ) );

	 // Create a section
	 CSF::createSection( $bizmax_wp_breadcrumb_options, array(
		'title'  => 'Breadcrumb Style',
		'fields' => array(
			array(
				'id'       => 'bc_page_background',
				'type'     => 'media',
				'title'    => esc_html__('Background Thumbnail', 'bizmax-wp' ),
				'desc' => esc_html__('Select default banner image for all page / post. You can override this settings in individual page / post.', 'bizmax-wp'),
			), 
			  
		)
	  ) );
  
  
  }