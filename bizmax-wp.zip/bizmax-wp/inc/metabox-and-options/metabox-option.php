<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $bizmax_wp_options = 'bizmax_wp_options';

  //
  // Create options
  CSF::createOptions( $bizmax_wp_options, array(
    'menu_title' => 'Bizmax Options',
    'menu_slug'  => 'bizmax-options',
	  'framework_title'         => 'Bizmax Options <small>by Laralink</small>',
	  'footer_text'             => '',
    'footer_after'            => '',
    'footer_credit'           => '',
  ) );

// Theme Options
require get_template_directory() . '/inc/metabox-and-options/theme-options.php';
// Page Options
require get_template_directory() . '/inc/metabox-and-options/page-metabox.php';
// Blog Options
require get_template_directory() . '/inc/metabox-and-options/blog-metabox.php';
// Breadcrumb Options
require get_template_directory() . '/inc/metabox-and-options/breadcrumb-metabox.php';

 

}