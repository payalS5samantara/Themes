<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

	// Header Settings
	CSF::createSection( $bizmax_wp_options, array(
		'id'    => 'primary_tab', // Set a unique slug-like ID
		'title'    => __('Header Settings', 'bizmax-wp'),
		'icon'   => 'fas fa-bars',
	) );

	// Topbar Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'primary_tab', // The slug id of the parent section
		'title'      => esc_html__('Topbar settings', 'bizmax-wp'),
		'icon'		 => 'fa fa-road',
		'fields' => array(
			
			// A textarea field
			array(
				'id'    => 'enable_topbar',
				'type'  => 'switcher',
				'default'  => true,
				'title' => esc_html__('Enable Topbar?', 'bizmax-wp'),
				'desc' => esc_html__('Do you want to enable topbar? Please select "ON" from switcher.', 'bizmax-wp'),
			),
			array(
				'id'        => 'topbar_contact_list',
				'type'      => 'group',
				'title'     => esc_html__('Topbar contact list', 'bizmax-wp'),
				'desc'      => esc_html__('If you want to show topbar contact list. Please add contact list here.', 'bizmax-wp'),
				'button_title' =>  esc_html__('Add new', 'bizmax-wp'),
				'accordion_title' => esc_html__('Add new contact list', 'bizmax-wp'),
				'fields'    => array(
					array(
						'id'    => 'focus',
						'type'  => 'text',
						'title' => esc_html__('Contact Focus', 'bizmax-wp'),
					),
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => esc_html__('Contact title', 'bizmax-wp'),
					),
					array(
						'id'    => 'link',
						'type'  => 'text',
						'title' => esc_html__('Contact link', 'bizmax-wp'),
						'desc' => esc_html__('Leave blank, if you do not want to show link', 'bizmax-wp'),
					),
				),
				'dependency' => array( 'enable_topbar', '==', 'true' )
			),
			array(
				'id'        => 'topbar_page_list',
				'type'      => 'group',
				'title'     =>  esc_html__('Topbar page list', 'bizmax-wp'),
				'desc'      => esc_html__('You can add with page link.', 'bizmax-wp'), 
				'button_title' => esc_html__('Add new', 'bizmax-wp'),
				'accordion_title' => esc_html__('Add new page', 'bizmax-wp'),
				'fields'    => array(
					array(
					'id'    => 'title',
					'type'  => 'text',
					'title' => esc_html__('Title', 'bizmax-wp'),
					),
					array(
					'id'    => 'link',
					'type'  => 'text',
					'title' => esc_html__('link', 'bizmax-wp'),
					'desc' => esc_html__('Leave blank, if you do not want to show link', 'bizmax-wp'),
					),
				),
				'dependency' => array( 'enable_topbar', '==', 'true' )
			),

		)
	) );

	// Header Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'primary_tab',
		'title'      => esc_html__('Header settings', 'bizmax-wp'),
		'icon'		 => 'fa fa-image',
		'fields' => array(
			array(
				'id'        => 'header_style',
				'type'      => 'select',
				'title'     => 'Select Header Style',
				'options'   => array(
					'1'   => esc_attr__('Style V1', 'bizmax-wp'),
					'style2'  => esc_attr__('Style V2', 'bizmax-wp'),
					'style3'  => esc_attr__('Style V3', 'bizmax-wp'),
				),
				'default'   => '1',
				'desc' => esc_html__('Select site header style.You can override this settings in individual page', 'bizmax-wp'),
				'radio' => true,
			),
			array(
				'id'    => 'enable_header_sticky',
				'type'  => 'switcher',
				'default'  => true,
				'title' => esc_html__('Header Sticky', 'bizmax-wp'),
				'desc' => esc_html__('Do you want to use header sticky? Please select "ON" from switcher.', 'bizmax-wp'),
			),
			array(
				'id'    => 'enable_image_logo',
				'type'  => 'switcher',
				'default'  => false,
				'title' => esc_html__('Header image logo', 'bizmax-wp'),
				'desc' => esc_html__('You can use image logo instead of text logo. Please select "ON" from switcher.', 'bizmax-wp'),
			),
			array(
				'id'    => 'image_logo',
				'type'  => 'media',
				'title' => esc_html__('Upload header logo', 'bizmax-wp'),
				'desc' => esc_html__('Upload your favorite logo by using add image option.', 'bizmax-wp'),
				'dependency' => array( 'enable_image_logo', '==', 'true' )
			),
			array(
				'id'    => 'image_logo_max_height',
				'type'  => 'text',
				'title' => esc_html__('logo max height', 'bizmax-wp'),
				'desc' => esc_html__('Type logo maximum height in "PX"', 'bizmax-wp'),
				'default' => '100',
				'dependency' => array( 'enable_image_logo', '==', 'true' )
			),
			array(
				'id'    => 'text_logo',
				'type'  => 'text',
				'title' => esc_html__('Header text logo', 'bizmax-wp'),
				'desc' => esc_html__('Type header text logo instead of image logo.', 'bizmax-wp'),
				'default' => 'Bizmax',
				'dependency' => array( 'enable_image_logo', '==', 'false' )
			),
			array(
				'id'    => 'search_form_show',
				'type'  => 'switcher',
				'default'  => true,
				'title' => esc_html__('Enable search form?', 'bizmax-wp'),
				'desc' => esc_html__('You can Enable/disable serch form by select switcher', 'bizmax-wp'),
			),
			array(
				'id'    => 'header_contact_show',
				'type'  => 'switcher',
				'default'  => true,
				'title' => esc_html__('Enable header contact?', 'bizmax-wp'),
				'desc' => esc_html__('You can Enable/disable contact by select switcher', 'bizmax-wp'),
			),
			array(
				'id'    => 'header_contact_title',
				'type'  => 'text',
				'default'  => 'Need help? Call us:',
				'title' => esc_html__('Header Contact', 'bizmax-wp'),
				'desc' => esc_html__('Type header contact title.', 'bizmax-wp'),
				'dependency' => array( 'header_contact_show', '==', 'true' )
			),
			array(
				'id'    => 'header_contact_info',
				'type'  => 'text',
				'default'  => '(+800) 1234 5678 90',
				'title' => esc_html__('(+800) 1234 5678 90', 'bizmax-wp'),
				'desc' => esc_html__('Type header contact info.', 'bizmax-wp'),
				'dependency' => array( 'header_contact_show', '==', 'true' )
			),
			

		)
	) );

	
	// Typography Settings
	CSF::createSection( $bizmax_wp_options, array(
		'title'      => esc_html__('Typography settings', 'bizmax-wp'),
		'icon'		 => 'fa fa-font',
		'fields' => array(
			array(
				'id'     	 => 'body_font',
				'type'   	 => 'typography',
				'title' 	 => esc_html__('Body font', 'bizmax-wp'),
				'desc'    => 'Select Body font, font weight and font style from dropdown.',
				'text_align' => false,
				'text_transform' => false,
				'default'	 => array(
					'color'       => '#636363',
					'font-family' => 'Poppins',
					'font-size'   => '15',
					'line-height' => '20',
					'font-weight' => '400',
					'unit'        => 'px',
					'type'        => 'google',
					
				),
			),
			array(
				'id'     	 => 'heading_font',
				'type'   	 => 'typography',
				'title' 	 => esc_html__('Heading font', 'bizmax-wp'),
				'desc'    => 'Select heading font, font weight and font style from dropdown.',
				'text_align' => false,
				'text_transform' => false,
				'default'	 => array(
					'color'       => '#232323',
					'font-family' => 'Poppins',
					'font-size'   => '15',
					'line-height' => '20',
					'font-weight' => '700',
					'unit'        => 'px',
					'type'        => 'google',
					
				),
			),

			array(
				'id'     	 => 'body_other_font',
				'type'   	 => 'typography',
				'title' 	 => esc_html__('Body other font', 'bizmax-wp'),
				'desc'    => 'Select heading font, font weight and font style from dropdown.',
				'text_align' => false,
				'text_transform' => false,
				'default'	 => array(
					'color'       => '#232323',
					'font-family' => 'Poppins',
					'font-size'   => '15',
					'line-height' => '20',
					'font-weight' => '500',
					'unit'        => 'px',
					'type'        => 'google',
					
				),
			),
			

		)
	) );


	// Header Settings
	CSF::createSection( $bizmax_wp_options, array(
		'id'    => 'layout_tabs', // Set a unique slug-like ID
		'title'    => __('Layout Settings', 'bizmax-wp'),
		'icon'   => 'fas fa-bars',
	) );

	// Topbar Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_tabs', // The slug id of the parent section
		'title'      => esc_html__('BreadCrumb settings', 'bizmax-wp'),
    	'icon'		 => 'fa fa-image',
		'fields' => array(

			array(
				'id'       => 'breadcrumb_background',
				'type'     => 'media',
				'title'    => esc_html__('Breadcrumb Bakckground Image', 'bizmax-wp' ),
				'desc' => esc_html__('Select default banner image for all page / post. You can override this settings in individual page / post.', 'bizmax-wp'),
			), 
		)
	) );

	// Blog Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_tabs',
		'title'      => esc_html__('Blog Page settings', 'bizmax-wp'),
		'icon'		 => 'fa fa-edit',
		'fields' => array(
			array(
				'id'       => 'blog_page_layout',
				'type'     => 'select',
				'title'    => esc_html__('Blog Page Layout', 'bizmax-wp'),
				'options'  => array(
					'left-sidebar'   => esc_attr__('Left Sidebar', 'bizmax-wp'),
					'right-sidebar' => esc_attr__('Right Sidebar', 'bizmax-wp'),
				),
				'default'  => 'right-sidebar',
				'desc' => esc_attr__('Select Blog Page layout.', 'bizmax-wp'),
			),
			array(
				'id'      => 'enable_blog_bc',
				'type'    => 'switcher',
				'title'   => esc_html__('Blog Breadcrumb', 'bizmax-wp'),
				'desc'	=> esc_html__('Do you want to show blog breadcrumb? Select ON option from switcher.', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'    => 'blog_main_bc_bg',
				'type'  => 'media',
				'title' => esc_html__('Blog Breadcrumb Background Image', 'bizmax-wp'),
				'desc' => esc_html__('Upload Blog page Breadcrumb background image.', 'bizmax-wp'),
				'dependency' => array( 'enable_blog_bc', '==', 'true' ),
			),
			array(
				'id'    => 'blog_bc_custom_title',
				'type'  => 'text',
				'title' => esc_html__('Blog Custom Title?', 'bizmax-wp'),
				'desc' => esc_html__('Blog page title', 'bizmax-wp'),
				'dependency' => array( 'enable_blog_bc', '==', 'true' ),
			),
			array(
				'id'      => 'blog_show_author_name',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post author name?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'blog_show_post_date',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post date?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'blog_show_post_comment',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post comment?', 'bizmax-wp'),
				'default' => true,
			),
		)
	) );

	// Blog Archive Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_tabs',
		'title'     => esc_html__('Archive Page settings', 'bizmax-wp'),
		'icon'     => 'fa fa-flag',
		'fields' => array(
			array(
				'id'       => 'blog_archive_layout',
				'type'     => 'select',
				'title'    => esc_html__('Archive Page Layout', 'bizmax-wp'),
				'options'  => array(
					'left-sidebar'   => esc_attr__('Left Sidebar', 'bizmax-wp'),
					'right-sidebar' => esc_attr__('Right Sidebar', 'bizmax-wp'),
					'full-width' => esc_attr__('Full Width', 'bizmax-wp')
				),
				'default'  => 'right-sidebar',
				'desc' => esc_html__('Select archive layout.', 'bizmax-wp'),
			),
			array(
				'id'      => 'enable_archive_bg',
				'type'    => 'switcher',
				'title'   => esc_html__('Archive Breadcrumb', 'bizmax-wp'),
				'desc'	=> esc_html__('Do you want to show blog archive breadcrumb? Select ON option from switcher.', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'    => 'blog_archive_bc_bg',
				'type'  => 'media',
				'title' => esc_html__('Blog Archive Breadcrumb', 'bizmax-wp'),
				'desc' => esc_html__('Upload Blog archvie page Breadcrumb background image.', 'bizmax-wp'),
				'dependency' => array( 'enable_archive_bg', '==', 'true' ),
			),
			array(
				'id'      => 'archive_show_author_name',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post author name?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'archive_show_post_date',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post date?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'archive_show_post_comment',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post comment?', 'bizmax-wp'),
				'default' => true,
			),
		)
	) );

	// Blog Single Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_tabs',
		'title'      => esc_html__('Blog Single page settings', 'bizmax-wp'),
		'icon'		 => 'fas fa-bars',
		'fields' => array(
			array(
				'id'       => 'post_default_layout',
				'type'     => 'select',
				'title'    => esc_html__('Layout', 'bizmax-wp'),
				'options'  => array(
					'full-width'   => esc_attr__('Full Width', 'bizmax-wp'),
					'left-sidebar'  => esc_attr__('Left Sidebar', 'bizmax-wp'),
					'right-sidebar' => esc_attr__('Right Sidebar', 'bizmax-wp')
				),
				'default'  => 'right-sidebar',
				'desc' => esc_html__('Select single post default layout. You can override this settings in individual post.', 'bizmax-wp'),
			),
			array(
				'id'      => 'single_show_author_name',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post author name?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'single_show_post_date',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post date?', 'bizmax-wp'),
				'default' => true,
			),
			array(
				'id'      => 'single_show_post_comment',
				'type'    => 'switcher',
				'desc'	=> esc_html__('You can Enable or Disable options from the switcher.', 'bizmax-wp'),
				'title'   => esc_html__('Show post comment?', 'bizmax-wp'),
				'default' => true,
			),
		)
	) );

	// Blog Single Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_tabs',
		'title'      => esc_html__('Search page settings', 'bizmax-wp'),
		'icon'		 => 'fa fa-search',
		'fields' => array(
			array(
				'id'    => 'search_bc_bg',
				'type'  => 'media',
				'title' => esc_html__('Search Page Breadcrumb', 'bizmax-wp'),
				'desc' => esc_html__('Upload search page Breadcrumb background image.', 'bizmax-wp'),
			),
		)
	) );


	// Header Settings
	CSF::createSection( $bizmax_wp_options, array(
		'id'    => 'layout_Footer', // Set a unique slug-like ID
		'title'    => __('Footer Settings', 'bizmax-wp'),
		'icon'   => 'fas fa-clone',
	) );

	// Footer Settings
	CSF::createSection( $bizmax_wp_options, array(
		'parent' => 'layout_Footer', // The slug id of the parent section
		'title'      => esc_html__('Footer settings', 'bizmax-wp'),
    	'icon'		 => 'fa fa-image',
		'fields' => array(
			array(
				'id'    => 'enable_footer',
				'type'  => 'switcher',
				'title' => 'Enable Footer?',
				'desc'	=> esc_html__('Do you want to use default footer? Select ON option from switcher.', 'bizmax-wp'),
				'default' => true,
				
			),
			array(
				'id'      => 'footer_bg_default',
				'type'    => 'media',
				'title'   => esc_html__('Footer background Image', 'bizmax-wp'),
				'desc'	=> esc_html__('Upload footer background image from library.', 'bizmax-wp'),
				'dependency' => array( 'enable_footer', '==', 'true' )
			),
			array(
				'id'      => 'footer_heading_color',
				'type'    => 'color',
				'title'   => esc_html__('Footer Heading color', 'bizmax-wp'),
				'desc'	=> esc_html__('Choose footer Heading color from color picker.', 'bizmax-wp'),
				'default' => esc_attr__('#fff', 'bizmax-wp'),
				'dependency' => array( 'enable_footer', '==', 'true' )
			),
			array(
				'id'      => 'footer_title_color',
				'type'    => 'color',
				'title'   => esc_html__('Footer Title color', 'bizmax-wp'),
				'desc'	=> esc_html__('Choose footer title color from color picker.', 'bizmax-wp'),
				'default' => esc_attr__('#fff', 'bizmax-wp'),
				'dependency' => array( 'enable_footer', '==', 'true' )
			),
			array(
				'id'      => 'footer_text_color',
				'type'    => 'color',
				'title'   => esc_html__('Footer text color', 'bizmax-wp'),
				'desc'	=> esc_html__('Choose footer text color from color picker.', 'bizmax-wp'),
				'default' => esc_attr__('#ccc', 'bizmax-wp'),
				'dependency' => array( 'enable_footer', '==', 'true' )
			),
			 array(
				'id'        => 'footer_copyright_text',
				'type'      => 'textarea',
				'default'  => '&copy; Copyright <a href="#">Bizmax</a>. Design & Development By <a target="_blank" href="#">Laralink</a>',
				'title' => __('Copyright Text', 'bizmax-wp'),
				'desc' => __('Type copyright text here.', 'bizmax-wp'),
				'dependency' => array( 'enable_footer', '==', 'true' )
			 ),

		)
	) );


	// Scripts Settings
	CSF::createSection( $bizmax_wp_options, array(
		'title'      => 'Script settings',
   		'icon'		 => 'fa fa-upload',
		'fields' => array(
			array(
				'id'    => 'bizmax_wp_custom_css',
				'type'  => 'textarea',
				'sanitize'  => false,
				'title' => esc_html__('Custom CSS', 'bizmax-wp'),
				'desc' => esc_html__('Add your own css here', 'bizmax-wp'),
			),
			array(
				'id'    => 'bizmax_wp_head_scripts',
				'type'  => 'textarea',
				'sanitize'  => false,
				'title' => esc_html__('Head Scripts', 'bizmax-wp'),
				'desc' => esc_html__('Scripts goes before closing < / head >', 'bizmax-wp'),
			),
			array(
				'id'    => 'bizmax_wp_body_scripts',
				'type'  => 'textarea',
				'sanitize'  => false,
				'title' => esc_html__('Footer Scripts', 'bizmax-wp'),
				'desc' => esc_html__('Scripts goes just before < / body >', 'bizmax-wp'),
			),

		)
	) );

	// Scripts Settings
	CSF::createSection( $bizmax_wp_options, array(
		'title'      => 'Theme Settings',
   		'icon'		 => 'fas fa-cog',
		'fields' => array(
		    array(
				'id'      => 'primary_color',
				'type'    => 'color',
				'title'   => esc_html__('Theme Primary color', 'bizmax-wp'),
				'desc'	=> esc_html__('Choose theme global color.', 'bizmax-wp'),
				'default' => esc_attr__('#e9a132', 'bizmax-wp'),
			),
			array(
				'id'    => 'enable_preloader',
				'type'  => 'switcher',
				'title' => 'Enable Preloader?',
				'desc'	=> esc_html__('Do you want to use preloader? Select ON option from switcher.', 'bizmax-wp'),
				'default' => true
			),
			array(
				'id'    => 'preloader_icon',
				'type'  => 'media',
				'title' => esc_html__('Preloader Icon', 'bizmax-wp'),
				'desc' => esc_html__('Upload image from media library.', 'bizmax-wp'),
				'dependency' => array( 'enable_preloader', '==', 'true' )
			),

		)
	) );


	
			
	// Export Import Settings
	CSF::createSection( $bizmax_wp_options, array(
		'title'      => 'Export & Import',
   		'icon'		 => 'fas fa-download',
		'fields' => array(
			array(
				'type'    => 'notice',
				'class'   => 'warning',
				'content' => 'You can save your current options. Download a Backup and Import.',
			),
			array(
				'type'    => 'backup',
			),

		)
	) );