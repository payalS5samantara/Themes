<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if( class_exists( 'CSF' ) ) {

    // Set a unique slug-like ID
    $bizmax_wp_blog_options = 'bizmax_wp_blog_options';
  
    // Create a metabox
    CSF::createMetabox( $bizmax_wp_blog_options, array(
	  'title'			=> esc_html__('Post Options', 'bizmax-wp'),
      'post_type' => 'post',
      'priority' => 'default',
    ) );
  
    // Create a section
    CSF::createSection( $bizmax_wp_blog_options, array(
      'title'			=> esc_html__('Post Options', 'bizmax-wp'),
      'fields' => array(
        array(
            'id'    => 'enable_featured_image',
            'type'  => 'switcher',
            'title' => esc_html__('Featured Image', 'bizmax-wp'),
            'desc' => esc_html__('Do you want to show featured Image on single page? So select "ON".', 'bizmax-wp'),
            'default' => true,
        ),
        array(
            'id'        => 'featured_image_upload',
            'type'      => 'media',
            'title'     => esc_html__('Upload Featured Image', 'bizmax-wp'),
            'desc' => esc_html__('Upload featured image for single page. If empty, default featured image will show on single page', 'bizmax-wp'),
            'dependency'   => array( 'enable_featured_image', '==', 'true' ),
        ),
      	)
    ) );


    // Create a section
    CSF::createSection( $bizmax_wp_blog_options, array(
        'title'			=> esc_html__('Post Layout', 'bizmax-wp'),
        'fields' => array(
                array(
                    'id'       => 'post_layout',
                    'type'     => 'select',
                    'title'    => esc_html__('Select Post Layout', 'bizmax-wp'),
                    'options'  => array(
                        '1'   => esc_attr__('Default', 'bizmax-wp'),
                        'left-sidebar'  => esc_attr__('Left Sidebar', 'bizmax-wp'),
                        'full-width'   => esc_attr__('Full Width', 'bizmax-wp'),
                        'right-sidebar' => esc_attr__('Right Sidebar', 'bizmax-wp')
                    ),
                    'default'  => 'right-sidebar',
                    'desc' => esc_html__('Select post sidebar layout.', 'bizmax-wp'),
                ),
            )
      ) );

    

	
  
  
  }


