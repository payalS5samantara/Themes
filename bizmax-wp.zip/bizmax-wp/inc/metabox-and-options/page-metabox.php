<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
// -----------------------------------------
// Page Header Metabox Options                    -
// -----------------------------------------

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $bizmax_wp_page_options = 'bizmax_wp_page_options';
  
    //
    // Create a metabox
    CSF::createMetabox( $bizmax_wp_page_options, array(
      'title'     => 'Page Settings',
      'post_type' => 'page',
    ) );
  
    //
    // Create a section
    CSF::createSection( $bizmax_wp_page_options, array(
      'title'  => 'Page Options',
      'fields' => array(
  
        array(
            'id'       => 'page_custom_logo',
            'type'     => 'media',
            'title'    => esc_html__('Upload Page Custom Logo', 'bizmax-wp' ),
            'desc' => esc_html__('Upload page custom logo.', 'bizmax-wp'),
        ),
        array(
            'id'    => 'enable_page_topbar',
            'type'  => 'switcher',
            'default'  => false,
            'title' => esc_html__('Enable Topbar?', 'bizmax-wp'),
            'desc' => esc_html__('Do you want to enable topbar? Please select "ON" from switcher Also do not forget to enable topbar from Theme Options', 'bizmax-wp'),
        ),
        array(
            'id'       => 'page_header',
            'type'     => 'select',
            'title'    => esc_html__('Select Page Header', 'bizmax-wp' ),
            'options'  => array(
                'default'   => esc_attr__('Default', 'bizmax-wp'),
                '1'  => esc_attr__('Style V1', 'bizmax-wp'),
                'style2'   => esc_attr__('Style V2', 'bizmax-wp'),
                'style3'   => esc_attr__('Style V3', 'bizmax-wp'),
            ),
            'default'  => 'default',
            'desc' => esc_html__('Select page header', 'bizmax-wp'),
        ), 
		  
        
      )
    ) );
}