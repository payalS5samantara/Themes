<?php

add_filter('comment_form_default_fields', 'sorex_comment_form');

function sorex_comment_form($sorex_fields){
	
    $sorex_fields['author'] = '
        <div class="row comment-form-wrap">
        <div class="col-lg-4 col-md-4 col-12">
            <div class="form-group">
                <input type="text" placeholder="'.esc_attr__('Your Name *', 'bizmax-wp').'"  name="author" id="name-cmt" required="required">
            </div>
        </div>
    ';

    $sorex_fields['email'] =  '
        <div class="col-lg-4 col-md-4 col-12">
            <div class="form-group">
                <input type="text" placeholder="'.esc_attr__('Your Email *', 'bizmax-wp').'"  name="email" id="email-cmt" required="required">
            </div>
        </div>
    ';

    $sorex_fields['url'] = '
        <div class="col-lg-4 col-md-4 col-12">
            <div class="form-group">
                <input type="text" placeholder="'.esc_attr__('Your Website ', 'bizmax-wp').'" name="url" id="website">
            </div>
        </div>
        </div>
        
    ';

    return $sorex_fields;
}


add_filter('comment_form_defaults', 'sorex_comment_default_form');

function sorex_comment_default_form($default_form){

    $default_form['comment_field'] = '
        <div class="row">
            <div class="col-12">
                <div class="comment-message">
                    <textarea placeholder="'.esc_attr__('Your Comment ', 'bizmax-wp').'" name="comment" rows="6" required="required"></textarea>
                </div>
            </div>
    ';

    $default_form['submit_button'] = '
        </div>
        <button type="submit" class="cs_btn cs_style_1 cs_fs_14 cs_rounded_5 cs_pl_30 cs_pr_30 cs_pt_10 cs_pb_10 overflow-hidden">'.esc_html__('Submit Comment', 'bizmax-wp').'</button>
    ';

    $default_form['comment_notes_before'] = esc_html__('All fields marked with an asterisk (*) are required', 'bizmax-wp' );
    $default_form['title_reply'] = esc_html__('Leave a comment', 'bizmax-wp');
    $default_form['title_reply_before'] = '<div class="bottom-title"><h2 class="comments-heading">';
    $default_form['title_reply_after'] = '</h2></div>';

    return $default_form;
}


function sorex_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}

add_filter( 'comment_form_fields', 'sorex_move_comment_field_to_bottom' );