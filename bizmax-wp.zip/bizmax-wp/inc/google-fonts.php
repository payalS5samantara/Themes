<?php

if( ! function_exists( 'bizmax_wp_google_fonts_url')) :
/** 
* Register Google fonts.
*
* @return string Google fonts URL for the theme.
*/
function bizmax_wp_google_fonts_url() {
	$fonts_url	=	'';
	
	
	$body_font 	= bizmax_wp_option('body_font');
	if(!empty($body_font)) {
		// Body Font & Variant Active
		$body_font 	= $body_font['font-family'];
	}else{
		$body_font = 'Poppins';
	}
	
	$heading_font 	= bizmax_wp_option('heading_font');
	if(!empty($heading_font)) {
		// Heading Font & Variant Active
		$heading_font 	= $heading_font['font-family'];
	}else{
		$heading_font = 'Poppins';
	}
	
	
	
	$fonts		=	array();
	$subsets		=	':300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
	
	$body_font	   .= $subsets; 
	$heading_font	   .= $subsets; 
	
	
	/* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language */
	if ( 'off' !== esc_html_x( 'on', 'Poppins font: on or off', 'bizmax-wp' ) ) {
		$fonts[] = $body_font;
	}
	
	/* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language */
	if ( 'off' !== esc_html_x( 'on', 'Poppins font: on or off', 'bizmax-wp' ) ) {
		$fonts[] = $heading_font;
	}
	
	if($fonts){
		 $fonts_url = add_query_arg(array(
			'family' => urlencode( implode( '|', $fonts ) ),
		 ), 'https://fonts.googleapis.com/css' );
	}
		
    return esc_url_raw( $fonts_url );
}
endif;

/** 
* Enqueue scripts and styles.
*/
function bizmax_wp_prefixs_scripts() {
	//add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'sorex-google-fonts', bizmax_wp_google_fonts_url(), array(), null );
}
add_action('wp_enqueue_scripts', 'bizmax_wp_prefixs_scripts' );	