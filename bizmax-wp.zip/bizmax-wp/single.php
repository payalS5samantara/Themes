<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package bizmax
 */

	$display_post_nav = bizmax_wp_option('display_post_nav');
	
	if (get_post_meta($post->ID, 'bizmax_wp_breadcrumb_options', true)) {
		$page_meta = get_post_meta($post->ID, 'bizmax_wp_breadcrumb_options', true);
	} else {
		$page_meta = array();
	}

	if(array_key_exists('enable_breadcrumb', $page_meta)){
		$enable_breadcrumb = $page_meta['enable_breadcrumb'];
	} else {
		$enable_breadcrumb = true;
	}
	

	//	Breadcrumb Background
	if (array_key_exists('bc_page_background', $page_meta)) {
		$bc_page_background = $page_meta['bc_page_background'];
	} else {
		$bc_page_background = false;
	}
	if ($bc_page_background) {
   		 $bc_page_background_src = wp_get_attachment_image_src($bc_page_background['id'], 'full', false);
	}
	if(array_key_exists('bc_custom_title', $page_meta)){
		$bc_custom_title = $page_meta['bc_custom_title'];
	} else {
		$bc_custom_title = '';
	}

	$breadcrumb_background = bizmax_wp_option('breadcrumb_background');
	if($breadcrumb_background){
	$breadcrumb_background_src = wp_get_attachment_image_src($breadcrumb_background['id'], 'full', false);
	}
	
	
	// Post Layout Meta
	if(get_post_meta($post->ID, 'bizmax_wp_blog_options', true)) {
    $bizmax_wp_blog_options = get_post_meta($post->ID, 'bizmax_wp_blog_options', true);
	} else {
		$bizmax_wp_blog_options = array();
	}

	$post_default_layout = bizmax_wp_option('post_default_layout');

	if(array_key_exists('post_layout', $bizmax_wp_blog_options) && $bizmax_wp_blog_options['post_layout'] != '1' ) {
		$post_layout = $bizmax_wp_blog_options['post_layout'];
	} elseif(!empty($post_default_layout)) {
		$post_layout = bizmax_wp_option('post_default_layout');
	}else{
		$post_layout = 'right-sidebar';
	}

	if(!empty($post_layout) && $post_layout != 'full-width' && is_active_sidebar( 'bizmax-blog-single-sidebar' )){
		$single_post_column = 'col-lg-8 col-12';
	}else{
		$single_post_column = 'col-lg-10 offset-lg-1 col-12';
	}
	
	
get_header(); ?>




	<!-- Breadcrumbs -->
	<?php if($enable_breadcrumb == true) : ?>

		<!-- breadcrumb-area-start-->
		<div class="cs_page_header position-relative background-filled d-flex align-items-center justify-content-between" <?php if(!empty($bc_page_background_src)) :?>
			data-src="<?php echo esc_url($bc_page_background_src[0]); ?>"
			<?php elseif(!empty($breadcrumb_background_src)) :?>
				data-src="<?php echo esc_url($breadcrumb_background_src[0]); ?>"
			<?php endif;?>>
			<div class="container position-relative z-index-1">
				<nav aria-label="breadcrumb" class="breadcrumb-nav cs_fs_18 cs_mb_5">
					<?php if (function_exists('bcn_display')) bcn_display(); ?>
				</nav>
				<h1 class="cs_fs_48 cs_fs_lg_36 text-white m-0"><?php if(!empty($bc_custom_title)) { echo esc_html($bc_custom_title); } else { the_title(); } ?></h1>
			</div>
			<div class="position-absolute end-0 bottom-0">
				<svg width="660" height="497" viewBox="0 0 660 497" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M240 0H660L430 497H0L240 0Z" fill="url(#paint0_linear_81_9510)"/>
					<defs>
					<linearGradient id="paint0_linear_81_9510" x1="330" y1="78.2497" x2="375.052" y2="780.743" gradientUnits="userSpaceOnUse">
					<stop stop-color="white" stop-opacity="0" offset="none"/>
					<stop offset="0.9999" stop-color="#D9D9D9" stop-opacity="0.35"/>
					<stop offset="1" stop-color="#222121" stop-opacity="0"/>
					<stop offset="1" stop-color="#222121" stop-opacity="0"/>
					</linearGradient>
					</defs>
				</svg> 
			</div>      
		</div>
		<!-- breadcrumb-area-start-->
		</div>
	<?php endif;?>



	<section class="bizmax-blog-main-section blog-single section-padding">
		
		<div class="bizmax-inner-post-area">
			<div class="container">
				<div class="row">
					<?php if(get_post_type() == 'post') : ?>

					<?php if( function_exists( 'bizmax_wp_option' ) && $post_layout == 'left-sidebar') : ?>
						<?php if(is_active_sidebar('bizmax-blog-single-sidebar')) : ?>
							<div class="col-lg-4 col-12">
								<aside class="sidebar-main"> 
									<?php dynamic_sidebar('bizmax-blog-single-sidebar'); ?>
								</aside>
							</div>
						<?php endif; ?>	
					<?php endif; ?>


					<?php if( function_exists( 'bizmax_wp_option' ) ) : ?>
					<div class="<?php echo esc_attr($single_post_column);?>">
						<?php elseif( ! function_exists( 'bizmax_wp_option' ) && is_active_sidebar('bizmax-blog-single-sidebar')) : ?>
						<div class="col-lg-8 col-12">
							<?php else :?>
						<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-12">
						<?php endif;?>
						<div class="row">
							<div class="col-12">
							<?php
								while ( have_posts() ) :
									the_post();
									get_template_part( 'template-parts/content', 'single' );
									// If comments are open or we have at least one comment, load up the comment template.
									if ( comments_open() || get_comments_number() ) :
										comments_template();
									endif;
									endwhile; // End of the loop.
								?>
							</div>
						</div>
					</div>

					<?php if( function_exists( 'bizmax_wp_option' ) && $post_layout == 'right-sidebar') : ?>
						<?php if(is_active_sidebar('bizmax-blog-single-sidebar')) : ?>
							<div class="col-lg-4 col-12">
								<aside class="sidebar-main"> 
									<?php dynamic_sidebar('bizmax-blog-single-sidebar'); ?>
								</aside>
							</div>
						<?php endif; ?>
					<?php endif; ?>
					<?php endif; ?>
					<?php  if ( ! function_exists( 'bizmax_wp_option' )) :?>
							<?php if(is_active_sidebar('bizmax-blog-single-sidebar')) : ?>
						<div class="col-lg-4 col-12">
							<aside class="sidebar-main"> 
								<?php dynamic_sidebar('bizmax-blog-single-sidebar'); ?>
							</aside>
						</div>
							<?php endif;?>
							<?php endif;?>

					
				</div>
			</div>
		</div>
	</section>
<?php
get_footer();
