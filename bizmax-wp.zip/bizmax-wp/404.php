<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package bizmax
 */

get_header();
?>
	
	<!-- Error Page --> 
	<div class="error__area pt-100 pb-150">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-8">
					<div class="error__item text-center">
						<div class="error__main-img pb-10 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
						<img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/error-img.png'); ?>" alt="<?php esc_attr_e('404 Image', 'bizmax-wp');?>">
						</div>
						<div class="error__text cs_mt_30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
							<h2 class="cs_fs_48 cs_fs_lg_36 mb-2"><?php esc_html_e( 'Page Not Found', 'bizmax-wp' ); ?></h2>
							<span><?php esc_html_e( 'Sorry This Page Not found take a look at our most popular', 'bizmax-wp'); ?> </span>
						</div>
						<div class="error__button wow tpfadeUp cs_mt_30" data-wow-duration=".9s" data-wow-delay=".7s">
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="cs_btn cs_style_1 cs_fs_14 cs_rounded_5 cs_pl_30 cs_pr_30 cs_pt_10 cs_pb_10 overflow-hidden"><span><span><?php esc_html_e( 'Go Home', 'bizmax-wp' );?></span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Error Page --> 

	
<?php
get_footer();
