<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bizmax
 */
	if(is_page() && get_post_meta($post->ID, 'header_meta', true)) {
		$header_meta = get_post_meta($post->ID, 'header_meta', true);
	} else {
		$header_meta = array();
    }
	$enable_footer = bizmax_wp_option('enable_footer');
	$image_logo = bizmax_wp_option('image_logo');
	$image_logo_max_height = bizmax_wp_option('image_logo_max_height');
	$text_logo = bizmax_wp_option('text_logo');
	$footer_copyright_text = bizmax_wp_option('footer_copyright_text');
	$footer_bg_default = bizmax_wp_option('footer_bg_default');
	if($footer_bg_default){
		$footer_bg_default_image_src = wp_get_attachment_image_src($footer_bg_default['id'], 'full', false);
	}
	
	
	$footer_style = bizmax_wp_option('footer_style');
	$default_footer_style = bizmax_wp_option('footer_style');

	if(array_key_exists('page_footer', $header_meta) && $header_meta['page_footer'] != 'default') {
		$footer_style = $header_meta['page_footer'];
	} elseif(!empty($default_footer_style)) {
		$footer_style = bizmax_wp_option('footer_style');
	}else{
		$footer_style = '1';
	}
	
	if(is_page() && get_post_meta($post->ID, 'bizmax_wp_page_options', true)) {
		$header_meta = get_post_meta($post->ID, 'bizmax_wp_page_options', true);
	} else {
		$header_meta = array();
	}
	
?>

	</main>

	<?php if(class_exists('CSF')) :?>
		<?php if($enable_footer) : ?>
		<footer>
			
			<div class="footer__area footer  footer__plr" 
			<?php if(!empty ($footer_bg_default_image_src[0])) :?> 
			data-src="<?php echo esc_url($footer_bg_default_image_src[0]) ?>"
			<?php endif;?>
			>

				<div class="container">
					<div class="row">
						<?php if(is_active_sidebar('bizmax-footer-1')) : ?>
						<div class="col-lg-4 col-12">
							<?php dynamic_sidebar('bizmax-footer-1'); ?>
						</div>
						<?php endif; ?>
						<?php if(is_active_sidebar('bizmax-footer-2')) : ?>
						<div class="col-lg-4 col-12">
							<?php dynamic_sidebar('bizmax-footer-2'); ?>
						</div>
						<?php endif; ?>
						<?php if(is_active_sidebar('bizmax-footer-3')) : ?>
						<div class="col-lg-4 col-12">
							<?php dynamic_sidebar('bizmax-footer-3'); ?>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<!-- footer-area-end -->
		
			<div class="cs_copyright text-center cs_fs_124 cs_lh_lg cs_pt_36 cs_pb_36">
				<div class="container">
					<?php if(!empty($footer_copyright_text)) : ?>
						<?php echo wp_kses_post($footer_copyright_text);  ?>
					<?php else :?>
						<?php esc_html_e('&copy; bizmax. Design & Development By LaraLink', 'bizmax-wp'); ?>
					<?php endif;?>
				</div>
			</div>
		</footer>
	<?php endif;?>
	<?php else :?>
	<div class="cs_copyright text-center cs_fs_124 cs_lh_lg cs_pt_36 cs_pb_36">
		<div class="container">
			<?php esc_html_e('&copy; bizmax. Design & Development By LaraLink', 'bizmax-wp'); ?>
		</div>
	</div>
	<?php endif;?>


		</div>
    </div>

	<?php wp_footer(); ?>
	</body>
</html>