<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package sorex
 */

	$enable_blog_bc = bizmax_wp_option('enable_blog_bc');
	$blog_bc_custom_title = bizmax_wp_option('blog_bc_custom_title');

	$blog_main_bc_bg = bizmax_wp_option('blog_main_bc_bg');
	if($blog_main_bc_bg){
		$blog_main_bc_bg_src = wp_get_attachment_image_src($blog_main_bc_bg['id'], 'full', false);
	}

	$breadcrumb_background = bizmax_wp_option('breadcrumb_background');
	if($breadcrumb_background){
		$breadcrumb_background_src = wp_get_attachment_image_src($breadcrumb_background['id'], 'full', false);
	}
	

	$blog_page_layout = bizmax_wp_option('blog_page_layout');
	if(!empty($blog_page_layout)){
		$blog_page_layout = bizmax_wp_option('blog_page_layout');
	}else{
		$blog_page_layout = 'right-sidebar';
	}

	if(!empty($blog_page_layout) && is_active_sidebar( 'bizmax-blog-sidebar' )){
		$main_col_class = 'col-lg-8 col-12';
	}else{
		$main_col_class = 'col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-12';
	}

	if(have_posts()){
		$blog_row_resize = 'grid';
	} else {
		$blog_row_resize = 'no-grid';
	}

get_header();
?>

	<!-- Breadcrumbs -->
	<?php if($enable_blog_bc == true) : ?>
		<div class="cs_page_header position-relative background-filled d-flex align-items-center justify-content-between" 
			<?php if(!empty($blog_main_bc_bg_src)) :?>
			data-src="<?php echo esc_url($blog_main_bc_bg_src[0]); ?>"
			<?php elseif(!empty($breadcrumb_background_src)) :?>
			data-src="<?php echo esc_url($breadcrumb_background_src[0]); ?>"
			<?php endif;?>>
			<div class="container position-relative z-index-1">
				<nav aria-label="breadcrumb" class="breadcrumb-nav cs_fs_18 cs_mb_5">
					<?php if (function_exists('bcn_display')) bcn_display(); ?>
				</nav>
				<h1 class="cs_fs_48 cs_fs_lg_36 text-white m-0"><?php if(!empty($blog_bc_custom_title)) { echo esc_html($blog_bc_custom_title); } else {  echo esc_html__('Read Latest Article', 'bizmax-wp'); } ?></h1>
			</div>
			<div class="position-absolute end-0 bottom-0">
				<svg width="660" height="497" viewBox="0 0 660 497" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M240 0H660L430 497H0L240 0Z" fill="url(#paint0_linear_81_9510)"/>
					<defs>
					<linearGradient id="paint0_linear_81_9510" x1="330" y1="78.2497" x2="375.052" y2="780.743" gradientUnits="userSpaceOnUse">
					<stop stop-color="white" stop-opacity="0" offset="none"/>
					<stop offset="0.9999" stop-color="#D9D9D9" stop-opacity="0.35"/>
					<stop offset="1" stop-color="#222121" stop-opacity="0"/>
					<stop offset="1" stop-color="#222121" stop-opacity="0"/>
					</linearGradient>
					</defs>
				</svg> 
			</div>      
		</div>
	<?php endif; ?>
	<!--/ End Breadcrumbs -->

	<div class="bizmax-internal-area bizmax-blog-main-section">
		<div class="container">
			<div class="row">
				<?php if($blog_page_layout == 'left-sidebar'){
					  get_sidebar();
				 }?>
				<div class="<?php echo esc_attr($main_col_class)?> <?php echo esc_attr($blog_page_layout) ?>">
					<div class="blog-main-layout bizmax-blog-main-section__archive">
						<div class="row <?php echo $blog_row_resize; ?>">
							<?php
								if ( have_posts() ) :

									if ( is_home() && ! is_front_page() ) :
										?>
										<header>
											<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
										</header>
										<?php
									endif;

									/* Start the Loop */
									while ( have_posts() ) :
										the_post();

										/*
										 * Include the Post-Type-specific template for the content.
										 * If you want to override this in a child theme, then include a file
										 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
										 */
										get_template_part( 'template-parts/content', get_post_type() );

									endwhile;

								?>

							<?php
								else :

									get_template_part( 'template-parts/content', 'none' );

								endif;
							?>
						</div>
						<div class="row">
							<div class="col-12">	
								<?php if ( function_exists( 'bizmax_wp_pagination' ) ) : ?>
								<div class="pagination-main">
									<?php bizmax_wp_pagination(); ?>
								</div>
								<?php endif;?>
							</div>
						</div>	
					</div>	
				</div>
				 <?php if($blog_page_layout == 'right-sidebar'){
					  get_sidebar();
				 }?>
			</div>
		</div>
	</div>
<?php
get_footer();
